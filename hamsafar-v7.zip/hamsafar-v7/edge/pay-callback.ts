// Supabase Edge Function: pay-callback
// آدرس بازگشت زرین‌پال. اینجا «پرداخت‌شده» فقط وقتی ثبت می‌شود که خود سرور، مستقیم از زرین‌پال
// تأیید (verify) گرفته باشد. پارامترهای آدرس (Status) هرگز به‌تنهایی مبنای تأیید نیستند.
//
// Secrets لازم:
//   ZARINPAL_MERCHANT_ID   شناسه‌ی پذیرنده
//   SITE_URL               آدرس سایت، مثلاً https://example.com/  (کاربر بعد از پرداخت به آنجا برمی‌گردد)
//   ZARINPAL_SANDBOX       اختیاری، "true" برای محیط آزمایشی
// «Verify JWT» این تابع باید خاموش باشد (مرورگر کاربر از درگاه به اینجا برمی‌گردد).

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

const sb = createClient(Deno.env.get("SUPABASE_URL"), Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"), {
  auth: { persistSession: false, autoRefreshToken: false },
});
const AUTHORITY = /^[A-Za-z0-9]{10,64}$/;
const sandbox = () => Deno.env.get("ZARINPAL_SANDBOX") === "true";
const apiBase = () => (sandbox() ? "https://sandbox.zarinpal.com" : "https://payment.zarinpal.com");

function siteUrl() {
  const u = String(Deno.env.get("SITE_URL") || "").trim().replace(/#.*$/, "");
  return /^https:\/\/[a-z0-9.-]+(:\d{1,5})?(\/[^\s]*)?$/i.test(u) || /^http:\/\/(localhost|127\.0\.0\.1)(:\d{1,5})?(\/[^\s]*)?$/i.test(u) ? u : "";
}
function back(code) {
  const site = siteUrl();
  if (!site) return new Response("SITE_URL is not configured", { status: 500 });
  return new Response(null, { status: 302, headers: { Location: site + "#me?pay=" + code, "Cache-Control": "no-store" } });
}

async function verify(authority, rial) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 15000);
  try {
    const r = await fetch(apiBase() + "/pg/v4/payment/verify.json", {
      method: "POST", signal: ctl.signal,
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({ merchant_id: Deno.env.get("ZARINPAL_MERCHANT_ID"), authority, amount: rial }),
    });
    return await r.json().catch(() => null);
  } finally { clearTimeout(timer); }
}

Deno.serve(async (req) => {
  if (req.method !== "GET") return new Response("method", { status: 405 });
  const q = new URL(req.url).searchParams;
  const authority = String(q.get("Authority") || "");
  const status = String(q.get("Status") || "");
  if (!AUTHORITY.test(authority) || !Deno.env.get("ZARINPAL_MERCHANT_ID")) return back("unknown");

  const found = await sb.from("commission_payments").select("id,amount,status,authority").eq("authority", authority).maybeSingle();
  if (found.error) return back("pending");
  const pay = found.data;
  if (!pay) return back("unknown");
  if (pay.status === "paid") return back("ok");                 // بازدید دوباره‌ی همان آدرس

  if (status !== "OK") {
    await sb.rpc("payment_mark_failed", { p_authority: authority, p_status: "canceled", p_reason: "user_canceled", p_detail: { status } });
    return back("canceled");
  }

  // تأیید مستقیم سرور با زرین‌پال؛ مبلغ از پایگاه داده است، نه از آدرس
  let res = null;
  try { res = await verify(authority, Number(pay.amount) * 10); }
  catch (_) { return back("pending"); }                         // نتیجه نامعلوم: چیزی را «ناموفق» نکنیم، کاربر می‌تواند دوباره امتحان کند
  const d = res && res.data && !Array.isArray(res.data) ? res.data : null;
  if (d && (d.code === 100 || d.code === 101)) {
    const m = await sb.rpc("payment_mark_paid", {
      p_authority: authority, p_ref_id: String(d.ref_id || ""), p_card_pan: String(d.card_pan || "").slice(0, 32),
      p_detail: { code: d.code, fee: d.fee || null },
    });
    if (m.error) return back("pending");
    return back(m.data && m.data.status === "duplicate" ? "duplicate" : "ok");
  }
  const code = d && d.code ? d.code : (res && res.errors && res.errors.code) || "unknown";
  await sb.rpc("payment_mark_failed", { p_authority: authority, p_status: "failed", p_reason: "zp_verify_" + code, p_detail: { code } });
  return back("failed");
});
