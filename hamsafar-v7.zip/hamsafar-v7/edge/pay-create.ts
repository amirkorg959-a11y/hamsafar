// Supabase Edge Function: pay-create
// ساخت تراکنش پرداخت کمیسیون یک سفر در زرین‌پال. روی سرور اجرا می‌شود، نه در مرورگر.
// مبلغ از پایگاه داده می‌آید، نه از مرورگر. Merchant ID فقط از Secrets خوانده می‌شود.
//
// Secrets لازم (Supabase ← Edge Functions ← Secrets):
//   ZARINPAL_MERCHANT_ID   شناسه‌ی پذیرنده‌ی زرین‌پال
//   ZARINPAL_SANDBOX       اختیاری. "true" برای آزمایش در محیط آزمایشی زرین‌پال
// SUPABASE_URL و SUPABASE_SERVICE_ROLE_KEY را خود Supabase به تابع می‌دهد.
// «Verify JWT» این تابع باید روشن بماند (راننده باید واردشده باشد).

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const reply = (obj, status = 200) =>
  new Response(JSON.stringify(obj), { status, headers: { ...cors, "Content-Type": "application/json" } });

const sb = createClient(Deno.env.get("SUPABASE_URL"), Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"), {
  auth: { persistSession: false, autoRefreshToken: false },
});
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const AUTHORITY = /^[A-Za-z0-9]{10,64}$/;
const sandbox = () => Deno.env.get("ZARINPAL_SANDBOX") === "true";
const apiBase = () => (sandbox() ? "https://sandbox.zarinpal.com" : "https://payment.zarinpal.com");
const startPay = () => (sandbox() ? "https://sandbox.zarinpal.com" : "https://www.zarinpal.com");
const KNOWN = ["not_found", "already_paid", "not_payable"];

async function zarinpal(path, body) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 15000);
  try {
    const r = await fetch(apiBase() + path, {
      method: "POST", signal: ctl.signal,
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify(body),
    });
    return await r.json().catch(() => null);
  } finally { clearTimeout(timer); }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
  if (req.method !== "POST") return reply({ error: "method" }, 405);
  const merchant = Deno.env.get("ZARINPAL_MERCHANT_ID");
  if (!merchant) return reply({ error: "gateway_not_configured" }, 503);

  // هویت راننده: از توکن ورود خودش، با تأیید سرور Supabase
  const auth = req.headers.get("authorization") || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
  if (!token) return reply({ error: "login_required" }, 401);
  const who = await sb.auth.getUser(token);
  const uid = who && who.data && who.data.user && who.data.user.id;
  if (!uid) return reply({ error: "login_required" }, 401);

  let body = null;
  try { body = await req.json(); } catch (_) { return reply({ error: "bad_request" }, 400); }
  const cid = String((body && body.commission_id) || "");
  if (!UUID.test(cid)) return reply({ error: "bad_request" }, 400);

  const begin = await sb.rpc("payment_begin", { p_commission: cid, p_driver: uid, p_gateway: "zarinpal" });
  if (begin.error) {
    const m = String(begin.error.message || "");
    const known = KNOWN.find((k) => m.includes(k));
    return reply({ error: known || "server" }, known ? 400 : 500);
  }
  const pid = begin.data.payment_id;
  const rial = Number(begin.data.amount) * 10;            // تومان ← ریال
  if (!Number.isInteger(rial) || rial < 10000) {
    await sb.rpc("payment_abort", { p_payment: pid, p_reason: "amount_too_small" });
    return reply({ error: "amount_too_small" }, 400);
  }

  let res = null;
  try {
    res = await zarinpal("/pg/v4/payment/request.json", {
      merchant_id: merchant,
      amount: rial,
      callback_url: Deno.env.get("SUPABASE_URL") + "/functions/v1/pay-callback",
      description: "کمیسیون سفر هم‌سفر",
      metadata: { order_id: pid },
    });
  } catch (_) {
    await sb.rpc("payment_abort", { p_payment: pid, p_reason: "gateway_unreachable" });
    return reply({ error: "gateway_unreachable" }, 502);
  }
  const d = res && res.data && !Array.isArray(res.data) ? res.data : null;
  if (!d || d.code !== 100 || typeof d.authority !== "string" || !AUTHORITY.test(d.authority)) {
    const code = d && d.code ? d.code : (res && res.errors && res.errors.code) || "unknown";
    await sb.rpc("payment_abort", { p_payment: pid, p_reason: "zp_request_" + code });
    return reply({ error: "gateway_error" }, 502);
  }
  const set = await sb.rpc("payment_set_authority", { p_payment: pid, p_authority: d.authority });
  if (set.error) return reply({ error: "server" }, 500);
  return reply({ url: startPay() + "/pg/StartPay/" + d.authority });
});
