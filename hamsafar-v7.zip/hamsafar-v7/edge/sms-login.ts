// Supabase Edge Function: sms-login
// ورود با شماره‌ی موبایل و کد پیامکی. این فایل روی سرور Supabase اجرا می‌شود، نه در مرورگر.
// کلیدهای محرمانه فقط از «Secrets» خوانده می‌شوند و هیچ‌جای سایت قرار نمی‌گیرند.
//
// Secrets لازم (Supabase ← Edge Functions ← Secrets):
//   KAVENEGAR_API_KEY   کلید API سرویس پیامک کاوه‌نگار
//   KAVENEGAR_TEMPLATE  نام قالب تأییدشده‌ی «verify/lookup» در کاوه‌نگار (که %token را دارد)
//   OTP_PEPPER          یک متن تصادفی بلند برای امن‌تر شدن کد ذخیره‌شده (اختیاری ولی پیشنهادی)
//   SMS_DAILY_LIMIT     سقف پیامک در شبانه‌روز، پیش‌فرض ۳۰۰ (اختیاری)
// SUPABASE_URL و SUPABASE_SERVICE_ROLE_KEY را خود Supabase به تابع می‌دهد.
// این تابع باید با گزینه‌ی «Verify JWT» خاموش ساخته شود، چون کاربر هنوز وارد نشده است.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const reply = (obj, status = 200) =>
  new Response(JSON.stringify(obj), { status, headers: { ...cors, "Content-Type": "application/json" } });

const sb = createClient(Deno.env.get("SUPABASE_URL"), Deno.env.get("SUPABASE_SERVICE_ROLE_KEY"), {
  auth: { persistSession: false, autoRefreshToken: false },
});

const PHONE = /^09[0-9]{9}$/;
const CODE = /^[0-9]{6}$/;

async function sha256(text) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
const hashCode = (code, phone) => sha256(code + ":" + phone + ":" + (Deno.env.get("OTP_PEPPER") || ""));

function newCode() {
  const n = new Uint32Array(1);
  crypto.getRandomValues(n);
  return String(n[0] % 1000000).padStart(6, "0");
}

async function send(phone) {
  const now = Date.now();
  const iso = (ms) => new Date(now - ms).toISOString();
  const count = async (sinceMs, onlyPhone) => {
    let q = sb.from("otp_codes").select("id", { count: "exact", head: true }).gt("created_at", iso(sinceMs));
    if (onlyPhone) q = q.eq("phone", phone);
    const r = await q;
    if (r.error) throw new Error("db");
    return r.count || 0;
  };
  if ((await count(60 * 1000, true)) > 0) return reply({ error: "wait_a_minute" }, 429);
  if ((await count(3600 * 1000, true)) >= 5) return reply({ error: "too_many_for_phone" }, 429);
  const daily = Number(Deno.env.get("SMS_DAILY_LIMIT")) || 300;
  if ((await count(24 * 3600 * 1000, false)) >= daily) return reply({ error: "daily_limit" }, 429);

  const key = Deno.env.get("KAVENEGAR_API_KEY"), tpl = Deno.env.get("KAVENEGAR_TEMPLATE");
  if (!key || !tpl) return reply({ error: "sms_not_configured" }, 503);

  const code = newCode();
  const ins = await sb.from("otp_codes").insert({
    phone, code_hash: await hashCode(code, phone), expires_at: new Date(now + 5 * 60 * 1000).toISOString(),
  }).select("id").single();
  if (ins.error) return reply({ error: "db" }, 500);

  let ok = false;
  try {
    const url = "https://api.kavenegar.com/v1/" + encodeURIComponent(key) + "/verify/lookup.json?receptor=" +
      encodeURIComponent(phone) + "&token=" + encodeURIComponent(code) + "&template=" + encodeURIComponent(tpl);
    const r = await fetch(url);
    const j = await r.json().catch(() => null);
    ok = r.ok && j && j.return && j.return.status === 200;
  } catch (_) { ok = false; }
  if (!ok) {
    await sb.from("otp_codes").delete().eq("id", ins.data.id);
    return reply({ error: "sms_failed" }, 502);
  }
  await sb.from("otp_codes").delete().lt("created_at", iso(24 * 3600 * 1000)); // پاک‌سازی کدهای قدیمی
  return reply({ ok: true });
}

async function verify(phone, code) {
  const r = await sb.from("otp_codes").select("*").eq("phone", phone).eq("used", false)
    .gt("expires_at", new Date().toISOString()).order("created_at", { ascending: false }).limit(1);
  if (r.error) return reply({ error: "db" }, 500);
  const row = r.data && r.data[0];
  if (!row) return reply({ error: "code_expired" }, 400);
  if (row.attempts >= 5) return reply({ error: "too_many_attempts" }, 429);
  await sb.from("otp_codes").update({ attempts: row.attempts + 1 }).eq("id", row.id);
  if ((await hashCode(code, phone)) !== row.code_hash) return reply({ error: "wrong_code" }, 400);
  await sb.from("otp_codes").update({ used: true }).eq("id", row.id);

  // هر شماره یک کاربر با ایمیل ساختگی ثابت است (ایمیلی ارسال نمی‌شود)
  const email = phone + "@phone.hamsafar.invalid";
  await sb.auth.admin.createUser({ email, email_confirm: true }); // اگر وجود داشته باشد خطا می‌دهد و نادیده گرفته می‌شود
  const link = await sb.auth.admin.generateLink({ type: "magiclink", email });
  if (link.error || !link.data || !link.data.properties || !link.data.user) return reply({ error: "login_failed" }, 500);
  const up = await sb.from("profiles").upsert({ id: link.data.user.id, phone, phone_verified: true }, { onConflict: "id" });
  if (up.error) return reply({ error: "db" }, 500);
  return reply({ token_hash: link.data.properties.hashed_token, type: "magiclink" });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 204, headers: cors });
  if (req.method !== "POST") return reply({ error: "method" }, 405);
  let body = null;
  try { body = await req.json(); } catch (_) { return reply({ error: "bad_request" }, 400); }
  const phone = String((body && body.phone) || "").trim();
  if (!PHONE.test(phone)) return reply({ error: "bad_phone" }, 400);
  try {
    if (body.action === "send") return await send(phone);
    if (body.action === "verify") {
      const code = String(body.code || "").trim();
      if (!CODE.test(code)) return reply({ error: "bad_code" }, 400);
      return await verify(phone, code);
    }
  } catch (_) { return reply({ error: "server" }, 500); }
  return reply({ error: "bad_request" }, 400);
});
