-- =====================================================================
--  هم‌سفر — مدیریت هوشمند (مرحله‌ی ۶)
--  بعد از supabase-setup.sql، supabase-hardening.sql، supabase-sms-required.sql
--  و supabase-commission.sql اجرا می‌شود. چند بار اجرا کردنش بی‌خطر است.
--
--  • هیچ جدول فعلی تغییر ساختاری نمی‌کند. فقط جدول‌های «جدید» ساخته می‌شود.
--  • فقط ۲ تابع فعلی بازنویسی می‌شود (ثبت سفر و درخواست صندلی) تا راننده‌ی مسدود
--    نتواند سفر جدید ثبت کند و مسافر نتواند از او صندلی بخواهد.
--  • همه‌ی توابع مدیر با is_admin() قفل‌اند و همه‌ی تغییرات در admin_audit ثبت می‌شود.
--  • هوش مصنوعی فقط «ai_report_data» (خواندنی و بی‌نام) را می‌بیند و فقط متن گزارش را ذخیره می‌کند.
-- =====================================================================

-- ۱) جدول‌های جدید ----------------------------------------------------
create table if not exists public.admin_audit (
  id          bigserial primary key,
  at          timestamptz not null default now(),
  admin_id    uuid,                          -- مدیر انجام‌دهنده (برای عملیات سیستمی خالی)
  action      text not null,
  target_type text,
  target_id   text,
  detail      jsonb not null default '{}'::jsonb
);
create index if not exists admin_audit_at_idx on public.admin_audit (at desc);

create table if not exists public.driver_blocks (
  driver_id  uuid primary key references auth.users(id) on delete cascade,
  reason     text not null check (char_length(btrim(reason)) between 3 and 200),
  blocked_at timestamptz not null default now(),
  blocked_by uuid
);

create table if not exists public.ai_reports (
  id         uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  admin_id   uuid,
  days       int not null,
  model      text,
  report     text not null check (char_length(report) <= 20000)
);

alter table public.admin_audit   enable row level security;
alter table public.driver_blocks enable row level security;
alter table public.ai_reports    enable row level security;
revoke all on public.admin_audit, public.driver_blocks, public.ai_reports from anon, authenticated;
-- هیچ سیاست و هیچ دسترسی مستقیمی برای کاربران نیست؛ فقط از راه توابع زیر.

-- ۲) نگهبان مدیر ------------------------------------------------------
create or replace function public._admin_guard()
returns void language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not_admin' using errcode = 'P0001'; end if;
  if public.require_verified()
     and not exists (select 1 from public.profiles where id = auth.uid() and coalesce(phone_verified, false)) then
    raise exception 'admin_phone_not_verified' using errcode = 'P0001';
  end if;
end;
$$;
revoke all on function public._admin_guard() from public, anon, authenticated;

create or replace function public._audit(p_action text, p_type text, p_target text, p_detail jsonb)
returns void language sql security definer set search_path = public as $$
  insert into public.admin_audit(admin_id, action, target_type, target_id, detail)
  values (auth.uid(), p_action, p_type, p_target, coalesce(p_detail, '{}'::jsonb))
$$;
revoke all on function public._audit(text, text, text, jsonb) from public, anon, authenticated;

-- ۳) محاسبه‌های داخلی (بدون نگهبان؛ فقط توابع زیر آن‌ها را صدا می‌زنند) ----------
create or replace function public._tday() returns date language sql stable as $$
  select (now() at time zone 'Asia/Tehran')::date
$$;

create or replace function public._overview() returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'today', public._tday(),
    'drivers', (select count(distinct d) from (select driver_id d from public.trips where driver_id is not null union select driver_id from public.commissions) x),
    'passengers', (select count(distinct passenger_id) from public.trip_requests),
    'profiles', (select count(*) from public.profiles),
    'verified_profiles', (select count(*) from public.profiles where coalesce(phone_verified, false)),
    'trips_open', (select count(*) from public.trips where status = 'open' and trip_date >= public._tday()),
    'trips_cancelled', (select count(*) from public.trips where status = 'cancelled'),
    'trips_stored', (select count(*) from public.trips),
    'trips_completed', (select count(*) from public.commissions),
    'requests_total', (select count(*) from public.trip_requests),
    'requests_approved', (select count(*) from public.trip_requests where status = 'approved'),
    'requests_pending', (select count(*) from public.trip_requests where status = 'pending'),
    'blocked', (select count(*) from public.driver_blocks),
    'commission_today', (select coalesce(sum(amount), 0) from public.commissions where (completed_at at time zone 'Asia/Tehran')::date = public._tday()),
    'revenue_today', (select coalesce(sum(amount), 0) from public.commissions where status = 'paid' and (paid_at at time zone 'Asia/Tehran')::date = public._tday()),
    'revenue_7d',  (select coalesce(sum(amount), 0) from public.commissions where status = 'paid' and (paid_at at time zone 'Asia/Tehran')::date > public._tday() - 7),
    'revenue_30d', (select coalesce(sum(amount), 0) from public.commissions where status = 'paid' and (paid_at at time zone 'Asia/Tehran')::date > public._tday() - 30),
    'revenue_total', (select coalesce(sum(amount), 0) from public.commissions where status = 'paid'),
    'due_amount', (select coalesce(sum(amount), 0) from public.commissions where status = 'due'),
    'due_count', (select count(*) from public.commissions where status = 'due'),
    'overdue_amount', (select coalesce(sum(amount), 0) from public.commissions where status = 'due' and due_at < now()),
    'overdue_count', (select count(*) from public.commissions where status = 'due' and due_at < now()),
    'debtors', (select count(distinct driver_id) from public.commissions where status = 'due'),
    'payments_paid_7d',   (select count(*) from public.commission_payments where status = 'paid' and created_at > now() - interval '7 days'),
    'payments_failed_7d', (select count(*) from public.commission_payments where status in ('failed','canceled') and created_at > now() - interval '7 days'),
    'payments_duplicate', (select count(*) from public.commission_payments where status = 'duplicate')
  )
$$;

create or replace function public._series(p_period text, p_count int) returns jsonb language plpgsql stable security definer set search_path = public as $$
declare n int := least(greatest(coalesce(p_count, 14), 1), 60); today date := public._tday(); first date; step interval; res jsonb;
begin
  if p_period not in ('day', 'week', 'month') then raise exception 'bad_period' using errcode = 'P0001'; end if;
  if p_period = 'day' then step := interval '1 day';   first := today - (n - 1);
  elsif p_period = 'week' then step := interval '7 days'; first := (date_trunc('week', (today + 2)::timestamp)::date - 2) - 7 * (n - 1);
  else step := interval '1 month'; first := (date_trunc('month', today::timestamp)::date - ((n - 1) || ' months')::interval)::date; end if;
  with b as (select g::date as bucket from generate_series(first, today, step) g),
  keyed as (
    select case p_period
             when 'day'   then x.d
             when 'week'  then (date_trunc('week', (x.d + 2)::timestamp)::date - 2)
             else date_trunc('month', x.d::timestamp)::date end as bucket, x.*
    from (
      select (paid_at at time zone 'Asia/Tehran')::date d, 'paid' k, amount, gross_amount from public.commissions where status = 'paid' and paid_at is not null
      union all
      select (completed_at at time zone 'Asia/Tehran')::date, 'calc', amount, gross_amount from public.commissions
    ) x
  )
  select coalesce(jsonb_agg(jsonb_build_object(
      'bucket', b.bucket,
      'paid_amount',  coalesce((select sum(amount) from keyed k where k.bucket = b.bucket and k.k = 'paid'), 0),
      'paid_count',   coalesce((select count(*) from keyed k where k.bucket = b.bucket and k.k = 'paid'), 0),
      'calc_amount',  coalesce((select sum(amount) from keyed k where k.bucket = b.bucket and k.k = 'calc'), 0),
      'gross_amount', coalesce((select sum(gross_amount) from keyed k where k.bucket = b.bucket and k.k = 'calc'), 0),
      'trips',        coalesce((select count(*) from keyed k where k.bucket = b.bucket and k.k = 'calc'), 0)
    ) order by b.bucket), '[]'::jsonb) into res from b;
  return res;
end;
$$;

create or replace function public._debts(p_limit int) returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(x order by (x->>'due_amount')::bigint desc), '[]'::jsonb) from (
    select jsonb_build_object(
      'driver_id', c.driver_id, 'name', p.name, 'phone', p.phone, 'phone_verified', coalesce(p.phone_verified, false),
      'due_count', count(*) filter (where c.status = 'due'),
      'due_amount', coalesce(sum(c.amount) filter (where c.status = 'due'), 0),
      'overdue_count', count(*) filter (where c.status = 'due' and c.due_at < now()),
      'overdue_amount', coalesce(sum(c.amount) filter (where c.status = 'due' and c.due_at < now()), 0),
      'oldest_due_at', min(c.due_at) filter (where c.status = 'due'),
      'paid_amount', coalesce(sum(c.amount) filter (where c.status = 'paid'), 0),
      'trips', count(*),
      'blocked', bool_or(b.driver_id is not null)
    ) as x
    from public.commissions c
    left join public.profiles p on p.id = c.driver_id
    left join public.driver_blocks b on b.driver_id = c.driver_id
    group by c.driver_id, p.name, p.phone, p.phone_verified
    having count(*) filter (where c.status = 'due') > 0
    order by coalesce(sum(c.amount) filter (where c.status = 'due'), 0) desc
    limit least(greatest(coalesce(p_limit, 50), 1), 200)
  ) q
$$;

create or replace function public._perf(p_days int, p_limit int) returns jsonb language sql stable security definer set search_path = public as $$
  with w as (select now() - (least(greatest(coalesce(p_days, 30), 1), 365) || ' days')::interval as since),
  t as (
    select driver_id, count(*) registered, count(*) filter (where status = 'cancelled') cancelled
    from public.trips, w where driver_id is not null and created_at >= w.since group by driver_id
  ),
  c as (
    select driver_id, count(*) completed, coalesce(sum(seats_total), 0) seats, coalesce(sum(gross_amount), 0) gross,
           coalesce(sum(amount) filter (where status = 'paid'), 0) paid, coalesce(sum(amount) filter (where status = 'due'), 0) due
    from public.commissions, w where completed_at >= w.since group by driver_id
  )
  select coalesce(jsonb_agg(x order by (x->>'completed')::int desc, (x->>'registered')::int desc), '[]'::jsonb) from (
    select jsonb_build_object(
      'driver_id', d.id, 'name', p.name, 'phone', p.phone,
      'registered', coalesce(t.registered, 0), 'cancelled', coalesce(t.cancelled, 0),
      'cancel_rate', case when coalesce(t.registered, 0) = 0 then 0 else round(100.0 * t.cancelled / t.registered) end,
      'completed', coalesce(c.completed, 0), 'seats', coalesce(c.seats, 0), 'gross', coalesce(c.gross, 0),
      'commission_paid', coalesce(c.paid, 0), 'commission_due', coalesce(c.due, 0),
      'blocked', b.driver_id is not null
    ) as x
    from (select driver_id as id from t union select driver_id from c) d
    left join t on t.driver_id = d.id left join c on c.driver_id = d.id
    left join public.profiles p on p.id = d.id
    left join public.driver_blocks b on b.driver_id = d.id
    order by coalesce(c.completed, 0) desc, coalesce(t.registered, 0) desc
    limit least(greatest(coalesce(p_limit, 50), 1), 200)
  ) q
$$;

create or replace function public._alerts() returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'cancelled_by_driver', (select coalesce(jsonb_agg(x order by (x->>'cancelled')::int desc), '[]'::jsonb) from (
        select jsonb_build_object('driver_id', t.driver_id, 'name', p.name, 'phone', p.phone, 'cancelled', count(*),
                                  'blocked', bool_or(b.driver_id is not null)) x
        from public.trips t left join public.profiles p on p.id = t.driver_id left join public.driver_blocks b on b.driver_id = t.driver_id
        where t.status = 'cancelled' and t.driver_id is not null and t.trip_date >= public._tday() - 7
        group by t.driver_id, p.name, p.phone order by count(*) desc limit 50) q),
    'overdue', (select coalesce(jsonb_agg(x order by (x->>'days_overdue')::int desc), '[]'::jsonb) from (
        select jsonb_build_object('commission_id', c.id, 'driver_id', c.driver_id, 'name', p.name, 'phone', p.phone, 'amount', c.amount,
                                  'due_at', c.due_at, 'days_overdue', greatest(0, extract(day from now() - c.due_at)::int),
                                  'blocked', b.driver_id is not null) x
        from public.commissions c left join public.profiles p on p.id = c.driver_id left join public.driver_blocks b on b.driver_id = c.driver_id
        where c.status = 'due' and c.due_at < now() order by c.due_at limit 50) q),
    'failed_payments', (select coalesce(jsonb_agg(x order by (x->>'at') desc), '[]'::jsonb) from (
        select jsonb_build_object('payment_id', p.id, 'amount', p.amount, 'status', p.status, 'reason', p.failure_reason, 'at', p.created_at) x
        from public.commission_payments p where p.status in ('failed', 'canceled') and p.created_at > now() - interval '7 days'
        order by p.created_at desc limit 30) q),
    'duplicate_payments', (select count(*) from public.commission_payments where status = 'duplicate'),
    'stuck_payments', (select count(*) from public.commission_payments where status = 'initiated' and created_at < now() - interval '1 hour')
  )
$$;
revoke all on function public._tday(), public._overview(), public._series(text, int), public._debts(int), public._perf(int, int), public._alerts()
  from public, anon, authenticated;

-- ۴) توابع مدیر (با نگهبان) ---------------------------------------------
create or replace function public.admin_overview() returns jsonb language plpgsql stable security definer set search_path = public as $$
begin perform public._admin_guard(); return public._overview(); end $$;
create or replace function public.admin_revenue_series(p_period text default 'day', p_count int default 14) returns jsonb language plpgsql stable security definer set search_path = public as $$
begin perform public._admin_guard(); return public._series(p_period, p_count); end $$;
create or replace function public.admin_driver_debts(p_limit int default 50) returns jsonb language plpgsql stable security definer set search_path = public as $$
begin perform public._admin_guard(); return public._debts(p_limit); end $$;
create or replace function public.admin_driver_performance(p_days int default 30, p_limit int default 50) returns jsonb language plpgsql stable security definer set search_path = public as $$
begin perform public._admin_guard(); return public._perf(p_days, p_limit); end $$;
create or replace function public.admin_alerts() returns jsonb language plpgsql stable security definer set search_path = public as $$
begin perform public._admin_guard(); return public._alerts(); end $$;

create or replace function public.admin_list_audit(p_limit int default 50, p_offset int default 0) returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  perform public._admin_guard();
  return (select coalesce(jsonb_agg(x order by (x->>'id')::bigint desc), '[]'::jsonb) from (
    select jsonb_build_object('id', a.id, 'at', a.at, 'admin_name', p.name, 'action', a.action, 'target_type', a.target_type,
                              'target_id', a.target_id, 'detail', a.detail) x
    from public.admin_audit a left join public.profiles p on p.id = a.admin_id
    order by a.id desc limit least(greatest(coalesce(p_limit, 50), 1), 200) offset greatest(coalesce(p_offset, 0), 0)) q);
end $$;

create or replace function public.admin_get_settings() returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  perform public._admin_guard();
  return (select jsonb_build_object('enabled', enabled, 'rate_bps', rate_bps, 'min_amount', min_amount, 'grace_days', grace_days) from public.commission_settings where id);
end $$;

-- تغییر تنظیمات (روی کمیسیون‌های «آینده» اثر دارد؛ کمیسیون‌های ثبت‌شده عوض نمی‌شوند)
create or replace function public.admin_update_settings(p_enabled boolean, p_rate_bps int, p_min_amount int, p_grace_days int)
returns jsonb language plpgsql security definer set search_path = public as $$
declare old jsonb; nw jsonb;
begin
  perform public._admin_guard();
  if p_rate_bps is null or p_rate_bps < 0 or p_rate_bps > 2000 then raise exception 'bad_rate' using errcode = 'P0001'; end if;
  if p_min_amount is null or p_min_amount < 0 or p_min_amount > 1000000 then raise exception 'bad_min' using errcode = 'P0001'; end if;
  if p_grace_days is null or p_grace_days < 0 or p_grace_days > 60 then raise exception 'bad_grace' using errcode = 'P0001'; end if;
  select jsonb_build_object('enabled', enabled, 'rate_bps', rate_bps, 'min_amount', min_amount, 'grace_days', grace_days) into old from public.commission_settings where id;
  update public.commission_settings set enabled = coalesce(p_enabled, enabled), rate_bps = p_rate_bps, min_amount = p_min_amount, grace_days = p_grace_days where id;
  select jsonb_build_object('enabled', enabled, 'rate_bps', rate_bps, 'min_amount', min_amount, 'grace_days', grace_days) into nw from public.commission_settings where id;
  perform public._audit('update_settings', 'commission_settings', 'main', jsonb_build_object('old', old, 'new', nw));
  return nw;
end $$;

-- مسدود/آزادسازی راننده
create or replace function public.admin_block_driver(p_driver uuid, p_reason text, p_cancel_open boolean default false)
returns jsonb language plpgsql security definer set search_path = public as $$
declare n int := 0;
begin
  perform public._admin_guard();
  if char_length(btrim(coalesce(p_reason, ''))) < 3 then raise exception 'reason_required' using errcode = 'P0001'; end if;
  if p_driver is null or not exists (select 1 from auth.users where id = p_driver) then raise exception 'not_found' using errcode = 'P0001'; end if;
  if exists (select 1 from public.app_admins where user_id = p_driver) then raise exception 'cannot_block_admin' using errcode = 'P0001'; end if;
  insert into public.driver_blocks(driver_id, reason, blocked_by) values (p_driver, left(btrim(p_reason), 200), auth.uid())
    on conflict (driver_id) do update set reason = excluded.reason, blocked_by = excluded.blocked_by, blocked_at = now();
  if p_cancel_open then
    update public.trips t set status = 'cancelled'
      where t.driver_id = p_driver and t.status = 'open'
        and (t.trip_date > public.tehran_today() or (t.trip_date = public.tehran_today() and t.depart_minute > public.tehran_minute()))
        and not exists (select 1 from public.commissions c where c.trip_id = t.id);
    get diagnostics n = row_count;
  end if;
  perform public._audit('block_driver', 'driver', p_driver::text, jsonb_build_object('reason', left(btrim(p_reason), 200), 'cancelled_open_trips', n));
  return jsonb_build_object('blocked', true, 'cancelled_open_trips', n);
end $$;

create or replace function public.admin_unblock_driver(p_driver uuid, p_reason text)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  perform public._admin_guard();
  if char_length(btrim(coalesce(p_reason, ''))) < 3 then raise exception 'reason_required' using errcode = 'P0001'; end if;
  delete from public.driver_blocks where driver_id = p_driver;
  if not found then raise exception 'not_found' using errcode = 'P0001'; end if;
  perform public._audit('unblock_driver', 'driver', p_driver::text, jsonb_build_object('reason', left(btrim(p_reason), 200)));
  return jsonb_build_object('blocked', false);
end $$;

-- بخشودن کمیسیون: همان تابع قبلی + ثبت در تاریخچه (و نگهبان تازه)
create or replace function public.admin_waive_commission(p_commission uuid, p_reason text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare c public.commissions;
begin
  perform public._admin_guard();
  if char_length(btrim(coalesce(p_reason, ''))) < 3 then raise exception 'reason_required' using errcode = 'P0001'; end if;
  select * into c from public.commissions where id = p_commission for update;
  if not found then raise exception 'not_found' using errcode = 'P0001'; end if;
  if c.status <> 'due' then raise exception 'already_decided' using errcode = 'P0001'; end if;
  update public.commissions set status = 'waived', waived_at = now(), waived_by = auth.uid(), waive_reason = left(btrim(p_reason), 200) where id = c.id;
  insert into public.payment_events(payment_id, kind, ok, detail)
    values (null, 'admin_waive', true, jsonb_build_object('commission_id', c.id, 'by', auth.uid(), 'reason', left(btrim(p_reason), 200)));
  perform public._audit('waive_commission', 'commission', c.id::text, jsonb_build_object('amount', c.amount, 'driver_id', c.driver_id, 'reason', left(btrim(p_reason), 200)));
  return jsonb_build_object('status', 'waived');
end $$;

-- راننده خودش بداند مسدود است یا نه
create or replace function public.my_block_status() returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce((select jsonb_build_object('blocked', true, 'reason', reason) from public.driver_blocks where driver_id = auth.uid()),
                  jsonb_build_object('blocked', false))
$$;
revoke all on function public.my_block_status() from public, anon;
grant execute on function public.my_block_status() to authenticated;

-- ۵) گزارش هوشمند: داده‌ی بی‌نام برای AI + ذخیره‌ی متن (فقط service_role) ----------
create or replace function public._anon_list(j jsonb) returns jsonb language sql immutable as $$
  select coalesce(jsonb_agg((e.v - 'driver_id' - 'name' - 'phone' - 'phone_verified' - 'payment_id' - 'commission_id')
                            || jsonb_build_object('driver', 'راننده ' || e.n) order by e.n), '[]'::jsonb)
  from jsonb_array_elements(j) with ordinality as e(v, n)
$$;
revoke all on function public._anon_list(jsonb) from public, anon, authenticated;

create or replace function public.ai_report_data(p_days int default 30) returns jsonb language plpgsql stable security definer set search_path = public as $$
declare d int := least(greatest(coalesce(p_days, 30), 7), 90); al jsonb := public._alerts();
begin
  return jsonb_build_object(
    'period_days', d,
    'overview', public._overview(),
    'daily_14', public._series('day', 14),
    'weekly_8', public._series('week', 8),
    'monthly_6', public._series('month', 6),
    'debtors', public._anon_list(public._debts(15)),
    'performance', public._anon_list(public._perf(d, 15)),
    'alerts', jsonb_build_object(
        'cancelled_by_driver', public._anon_list(al->'cancelled_by_driver'),
        'overdue', public._anon_list(al->'overdue'),
        'failed_payments_count', jsonb_array_length(al->'failed_payments'),
        'duplicate_payments', al->'duplicate_payments',
        'stuck_payments', al->'stuck_payments'),
    'note', 'trips older than 30 days are deleted by the cleanup job, so trip counts cover at most 30 days; commission figures are lifetime'
  );
end $$;

create or replace function public.ai_report_save(p_admin uuid, p_days int, p_model text, p_report text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare rid uuid;
begin
  if p_admin is null or not exists (select 1 from public.app_admins where user_id = p_admin) then raise exception 'not_admin' using errcode = 'P0001'; end if;
  insert into public.ai_reports(admin_id, days, model, report) values (p_admin, p_days, left(coalesce(p_model, ''), 80), left(p_report, 20000)) returning id into rid;
  insert into public.admin_audit(admin_id, action, target_type, target_id, detail) values (p_admin, 'ai_report', 'ai_report', rid::text, jsonb_build_object('days', p_days, 'model', left(coalesce(p_model, ''), 80)));
  return jsonb_build_object('id', rid);
end $$;
revoke all on function public.ai_report_data(int), public.ai_report_save(uuid, int, text, text) from public, anon, authenticated;
grant execute on function public.ai_report_data(int), public.ai_report_save(uuid, int, text, text) to service_role;


-- بررسی مدیر بودن برای تابع AI (فقط service_role) + سقف تعداد گزارش
create or replace function public.ai_check_admin(p_user uuid) returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  if p_user is null or not exists (select 1 from public.app_admins where user_id = p_user) then raise exception 'not_admin' using errcode = 'P0001'; end if;
  if public.require_verified() and not exists (select 1 from public.profiles where id = p_user and coalesce(phone_verified, false)) then
    raise exception 'admin_phone_not_verified' using errcode = 'P0001';
  end if;
  if exists (select 1 from public.ai_reports where created_at > now() - interval '60 seconds')
     or (select count(*) from public.ai_reports where created_at > now() - interval '1 day') >= 30 then
    raise exception 'ai_rate_limited' using errcode = 'P0001';
  end if;
  return jsonb_build_object('ok', true);
end $$;
revoke all on function public.ai_check_admin(uuid) from public, anon, authenticated;
grant execute on function public.ai_check_admin(uuid) to service_role;

create or replace function public.admin_list_ai_reports(p_limit int default 10) returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  perform public._admin_guard();
  return (select coalesce(jsonb_agg(x order by (x->>'created_at') desc), '[]'::jsonb) from (
    select jsonb_build_object('id', r.id, 'created_at', r.created_at, 'days', r.days, 'model', r.model, 'report', r.report) x
    from public.ai_reports r order by r.created_at desc limit least(greatest(coalesce(p_limit, 10), 1), 50)) q);
end $$;

-- دسترسی‌ها
revoke all on function public.admin_overview(), public.admin_revenue_series(text, int), public.admin_driver_debts(int),
  public.admin_driver_performance(int, int), public.admin_alerts(), public.admin_list_audit(int, int), public.admin_get_settings(),
  public.admin_update_settings(boolean, int, int, int), public.admin_block_driver(uuid, text, boolean), public.admin_unblock_driver(uuid, text),
  public.admin_waive_commission(uuid, text), public.admin_list_ai_reports(int) from public, anon;
grant execute on function public.admin_overview(), public.admin_revenue_series(text, int), public.admin_driver_debts(int),
  public.admin_driver_performance(int, int), public.admin_alerts(), public.admin_list_audit(int, int), public.admin_get_settings(),
  public.admin_update_settings(boolean, int, int, int), public.admin_block_driver(uuid, text, boolean), public.admin_unblock_driver(uuid, text),
  public.admin_waive_commission(uuid, text), public.admin_list_ai_reports(int) to authenticated;

-- ۶) اجرای قفل مسدودسازی (بازنویسی دو تابعِ فعلی؛ بقیه‌ی منطق دقیقاً مثل قبل است) ----------
create or replace function public.trips_before_insert()
returns trigger language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); p record;
begin
  if uid is null then raise exception 'login_required' using errcode = 'P0001'; end if;
  select name, phone, phone_verified into p from public.profiles where id = uid;
  if not found or p.name is null or p.phone is null then
    raise exception 'profile_required' using errcode = 'P0001';
  end if;
  if public.require_verified() and not coalesce(p.phone_verified, false) then
    raise exception 'phone_not_verified' using errcode = 'P0001';
  end if;
  if exists (select 1 from public.driver_blocks where driver_id = uid) then
    raise exception 'driver_blocked' using errcode = 'P0001';
  end if;
  if (select count(*) from public.trips
        where driver_id = uid and status = 'open' and trip_date >= public.tehran_today()) >= 10 then
    raise exception 'too_many_open_trips' using errcode = 'P0001';
  end if;
  new.driver_id   := uid;
  new.driver_name := p.name;
  new.status      := 'open';
  new.seats_taken := 0;
  return new;
end;
$$;

create or replace function public.request_seat(p_trip uuid, p_seats int)
returns jsonb language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); t public.trips; r public.trip_requests; p record; rid uuid;
begin
  if uid is null then raise exception 'login_required' using errcode = 'P0001'; end if;
  select name, phone, phone_verified into p from public.profiles where id = uid;
  if not found or p.name is null or p.phone is null then raise exception 'profile_required' using errcode = 'P0001'; end if;
  if public.require_verified() and not coalesce(p.phone_verified, false) then
    raise exception 'phone_not_verified' using errcode = 'P0001';
  end if;
  select * into t from public.trips where id = p_trip for update;
  if not found or t.status <> 'open' or t.driver_id is null
     or t.trip_date < public.tehran_today()
     or (t.trip_date = public.tehran_today() and t.depart_minute <= public.tehran_minute())
     or exists (select 1 from public.driver_blocks where driver_id = t.driver_id) then
    raise exception 'trip_not_available' using errcode = 'P0001';
  end if;
  if t.driver_id = uid then raise exception 'own_trip' using errcode = 'P0001'; end if;
  if p_seats is null or p_seats < 1 or p_seats > t.capacity - t.seats_taken then
    raise exception 'not_enough_seats' using errcode = 'P0001';
  end if;
  if (select count(*) from public.trip_requests where passenger_id = uid and status = 'pending') >= 10 then
    raise exception 'too_many_requests' using errcode = 'P0001';
  end if;
  select * into r from public.trip_requests where trip_id = p_trip and passenger_id = uid for update;
  if found then
    if r.status in ('pending','approved') then raise exception 'already_requested' using errcode = 'P0001'; end if;
    if r.status = 'rejected' then raise exception 'already_rejected' using errcode = 'P0001'; end if;
    update public.trip_requests set seats = p_seats, status = 'pending', decided_at = null, created_at = now()
      where id = r.id returning id into rid;
  else
    insert into public.trip_requests(trip_id, passenger_id, seats) values (p_trip, uid, p_seats) returning id into rid;
  end if;
  return jsonb_build_object('request_id', rid, 'status', 'pending');
end;
$$;

-- ---------------------------------------------------------------------
-- راه‌اندازی:
--  ۱) خودتان را مدیر کنید (اگر قبلاً نکرده‌اید):
--       insert into public.app_admins(user_id) values ('<شناسه‌ی شما>');
--     (صفحه‌ی admin.html همین دستور را با شناسه‌ی شما نشان می‌دهد.)
--  ۲) توصیه: ورود پیامکی اجباری را روشن کنید تا مدیر حتماً شماره‌ی تأییدشده داشته باشد.
-- ---------------------------------------------------------------------
