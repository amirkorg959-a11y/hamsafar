-- =====================================================================
-- هم‌سفر (نسخه ۲): جدول‌ها و قفل‌های امنیتی در Supabase
-- این فایل را در Supabase، بخش SQL Editor، اجرا کنید.
-- اگر نسخه‌ی ۱ را قبلاً اجرا کرده‌اید، همین فایل آن را به‌روز می‌کند.
-- اجرای دوباره‌ی آن خطرناک نیست و سفرهای قبلی را پاک نمی‌کند.
--
-- قواعد امنیتی:
--  * همه می‌توانند سفرهای باز و آینده را ببینند.
--  * فقط کاربر واردشده (ناشناس یا با شماره‌ی تأییدشده) می‌تواند سفر ثبت کند،
--    و نام راننده را پایگاه داده از نمایه‌ی او می‌گذارد، نه سایت.
--  * درخواست صندلی، تأیید یا رد و لغو فقط از راه تابع‌های زیر انجام می‌شود
--    و هر کدام مالک را بررسی می‌کند. جدول درخواست‌ها مستقیم باز نیست.
--  * شماره‌ی تلفن فقط بعد از تأیید راننده به طرف مقابل نشان داده می‌شود.
--  * مقدارهای نامعقول رد می‌شوند و ثبت انبوه محدود است.
-- =====================================================================

-- ۱) جدول سفرها
create table if not exists public.trips (
  id            uuid primary key default gen_random_uuid(),
  created_at    timestamptz not null default now(),
  origin        text     not null,
  destination   text     not null,
  trip_date     date     not null,
  depart_minute smallint not null,
  capacity      smallint not null,
  price         integer  not null,
  constraint trips_origin_len  check (char_length(btrim(origin))      between 2 and 40),
  constraint trips_dest_len    check (char_length(btrim(destination)) between 2 and 40),
  constraint trips_different   check (btrim(origin) <> btrim(destination)),
  constraint trips_no_markup   check (origin !~ '[<>]' and destination !~ '[<>]'),
  constraint trips_minute      check (depart_minute between 0 and 1439),
  constraint trips_capacity    check (capacity between 1 and 6),
  constraint trips_price       check (price between 10000 and 5000000)
);

-- ستون‌های نسخه‌ی ۲
alter table public.trips add column if not exists driver_id   uuid references auth.users(id) on delete set null;
alter table public.trips add column if not exists driver_name text;
alter table public.trips add column if not exists car         text;
alter table public.trips add column if not exists meet        text;
alter table public.trips add column if not exists status      text     not null default 'open';
alter table public.trips add column if not exists seats_taken smallint not null default 0;

alter table public.trips drop constraint if exists trips_status;
alter table public.trips add  constraint trips_status check (status in ('open','cancelled'));
alter table public.trips drop constraint if exists trips_seats;
alter table public.trips add  constraint trips_seats  check (seats_taken between 0 and capacity);
alter table public.trips drop constraint if exists trips_car_len;
alter table public.trips add  constraint trips_car_len  check (car  is null or (char_length(btrim(car))  between 1 and 40 and car  !~ '[<>]'));
alter table public.trips drop constraint if exists trips_meet_len;
alter table public.trips add  constraint trips_meet_len check (meet is null or (char_length(btrim(meet)) between 1 and 80 and meet !~ '[<>]'));

create index if not exists trips_date_idx   on public.trips (trip_date, depart_minute);
create index if not exists trips_driver_idx on public.trips (driver_id);

-- ۲) نمایه‌ی کاربران (نام و شماره). نوشتن فقط با تابع save_profile یا سرور پیامک.
create table if not exists public.profiles (
  id             uuid primary key references auth.users(id) on delete cascade,
  name           text,
  phone          text,
  phone_verified boolean not null default false,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  constraint profiles_name  check (name  is null or (char_length(btrim(name)) between 2 and 30 and name !~ '[<>]')),
  constraint profiles_phone check (phone is null or phone ~ '^09[0-9]{9}$')
);
create unique index if not exists profiles_verified_phone_uq on public.profiles (phone) where phone_verified;

-- ۳) درخواست‌های صندلی
create table if not exists public.trip_requests (
  id           uuid primary key default gen_random_uuid(),
  trip_id      uuid not null references public.trips(id) on delete cascade,
  passenger_id uuid not null references auth.users(id) on delete cascade,
  seats        smallint not null,
  status       text not null default 'pending',
  created_at   timestamptz not null default now(),
  decided_at   timestamptz,
  constraint req_seats  check (seats between 1 and 6),
  constraint req_status check (status in ('pending','approved','rejected','cancelled')),
  constraint req_unique unique (trip_id, passenger_id)
);
create index if not exists req_passenger_idx on public.trip_requests (passenger_id);

-- ۴) کدهای پیامکی (فقط سرور پیامک به آن دسترسی دارد)
create table if not exists public.otp_codes (
  id         uuid primary key default gen_random_uuid(),
  phone      text not null,
  code_hash  text not null,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null,
  attempts   smallint not null default 0,
  used       boolean not null default false
);
create index if not exists otp_phone_idx on public.otp_codes (phone, created_at desc);

-- ۵) توابع کمکی
create or replace function public.tehran_today() returns date
language sql stable as $$ select (now() at time zone 'Asia/Tehran')::date $$;

create or replace function public.tehran_minute() returns int
language sql stable as $$
  select extract(hour from now() at time zone 'Asia/Tehran')::int * 60
       + extract(minute from now() at time zone 'Asia/Tehran')::int $$;

-- ۶) محدودیت ثبت انبوه سفر + پر کردن خودکار فیلدهای حساس هنگام ثبت
create or replace function public.trips_throttle()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if (select count(*) from public.trips where created_at > now() - interval '10 minutes') >= 60 then
    raise exception 'too_many_trips_recently' using errcode = 'P0001';
  end if;
  if (select count(*) from public.trips) >= 5000 then
    raise exception 'trip_table_full' using errcode = 'P0001';
  end if;
  return new;
end;
$$;

drop trigger if exists trips_throttle_trg on public.trips;
create trigger trips_throttle_trg before insert on public.trips
  for each row execute function public.trips_throttle();

create or replace function public.trips_before_insert()
returns trigger language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); p record;
begin
  if uid is null then raise exception 'login_required' using errcode = 'P0001'; end if;
  select name, phone into p from public.profiles where id = uid;
  if not found or p.name is null or p.phone is null then
    raise exception 'profile_required' using errcode = 'P0001';
  end if;
  if (select count(*) from public.trips
        where driver_id = uid and status = 'open' and trip_date >= public.tehran_today()) >= 10 then
    raise exception 'too_many_open_trips' using errcode = 'P0001';
  end if;
  new.driver_id   := uid;
  new.driver_name := p.name;
  new.status      := 'open';
  new.seats_taken := 0;
  return new;
end;
$$;

drop trigger if exists trips_before_insert_trg on public.trips;
create trigger trips_before_insert_trg before insert on public.trips
  for each row execute function public.trips_before_insert();

-- ۷) قفل ایمنی (RLS)
alter table public.trips         enable row level security;
alter table public.profiles      enable row level security;
alter table public.trip_requests enable row level security;
alter table public.otp_codes     enable row level security;

revoke all on public.trips         from anon, authenticated;
revoke all on public.profiles      from anon, authenticated;
revoke all on public.trip_requests from anon, authenticated;
revoke all on public.otp_codes     from anon, authenticated;

grant select on public.trips to anon, authenticated;
-- فقط این ستون‌ها از سایت پذیرفته می‌شوند. بقیه (راننده، نام، وضعیت، صندلی پرشده) را پایگاه داده می‌سازد.
grant insert (origin, destination, trip_date, depart_minute, capacity, price, car, meet)
  on public.trips to authenticated;
grant select on public.profiles to authenticated;

-- سفرها: همه سفر باز آینده‌ی دارای راننده را می‌بینند؛ راننده سفرهای خودش را هم.
-- (سفرهای نسخه‌ی ۱ راننده ندارند و دیگر نمایش داده نمی‌شوند. حذفشان از Table Editor آزاد است.)
drop policy if exists "trips_select_future" on public.trips;
drop policy if exists "trips_select_v2"     on public.trips;
create policy "trips_select_v2" on public.trips
  for select to anon, authenticated
  using (driver_id is not null
         and ((status = 'open' and trip_date >= public.tehran_today()) or driver_id = auth.uid()));

drop policy if exists "trips_insert_valid_date" on public.trips;
drop policy if exists "trips_insert_v2"         on public.trips;
create policy "trips_insert_v2" on public.trips
  for insert to authenticated
  with check (
    driver_id = auth.uid()
    and trip_date between public.tehran_today() and public.tehran_today() + 60
    and (trip_date > public.tehran_today() or depart_minute > public.tehran_minute())
  );
-- عمداً هیچ سیاستی برای ویرایش یا حذف مستقیم وجود ندارد.

drop policy if exists "profiles_select_own" on public.profiles;
create policy "profiles_select_own" on public.profiles
  for select to authenticated using (id = auth.uid());

-- ۸) توابع برنامه. همه security definer هستند و خودشان هویت و مالک را بررسی می‌کنند.

-- ذخیره‌ی نام و شماره‌ی کاربر. اگر شماره با پیامک تأیید شده باشد، تغییر نمی‌کند.
create or replace function public.save_profile(p_name text, p_phone text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); n text := btrim(coalesce(p_name,'')); ph text := btrim(coalesce(p_phone,'')); r public.profiles;
begin
  if uid is null then raise exception 'login_required' using errcode = 'P0001'; end if;
  if char_length(n) < 2 or char_length(n) > 30 or n ~ '[<>]' then raise exception 'bad_name' using errcode = 'P0001'; end if;
  if ph !~ '^09[0-9]{9}$' then raise exception 'bad_phone' using errcode = 'P0001'; end if;
  insert into public.profiles(id, name, phone) values (uid, n, ph)
  on conflict (id) do update
    set name = excluded.name,
        phone = case when public.profiles.phone_verified then public.profiles.phone else excluded.phone end,
        updated_at = now()
  returning * into r;
  return jsonb_build_object('name', r.name, 'phone', r.phone, 'phone_verified', r.phone_verified);
end;
$$;

-- درخواست صندلی توسط مسافر
create or replace function public.request_seat(p_trip uuid, p_seats int)
returns jsonb language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); t public.trips; r public.trip_requests; p record; rid uuid;
begin
  if uid is null then raise exception 'login_required' using errcode = 'P0001'; end if;
  select name, phone into p from public.profiles where id = uid;
  if not found or p.name is null or p.phone is null then raise exception 'profile_required' using errcode = 'P0001'; end if;
  select * into t from public.trips where id = p_trip for update;
  if not found or t.status <> 'open' or t.driver_id is null
     or t.trip_date < public.tehran_today()
     or (t.trip_date = public.tehran_today() and t.depart_minute <= public.tehran_minute()) then
    raise exception 'trip_not_available' using errcode = 'P0001';
  end if;
  if t.driver_id = uid then raise exception 'own_trip' using errcode = 'P0001'; end if;
  if p_seats is null or p_seats < 1 or p_seats > t.capacity - t.seats_taken then
    raise exception 'not_enough_seats' using errcode = 'P0001';
  end if;
  if (select count(*) from public.trip_requests where passenger_id = uid and status = 'pending') >= 10 then
    raise exception 'too_many_requests' using errcode = 'P0001';
  end if;
  select * into r from public.trip_requests where trip_id = p_trip and passenger_id = uid for update;
  if found then
    if r.status in ('pending','approved') then raise exception 'already_requested' using errcode = 'P0001'; end if;
    if r.status = 'rejected' then raise exception 'already_rejected' using errcode = 'P0001'; end if;
    update public.trip_requests set seats = p_seats, status = 'pending', decided_at = null, created_at = now()
      where id = r.id returning id into rid;
  else
    insert into public.trip_requests(trip_id, passenger_id, seats) values (p_trip, uid, p_seats) returning id into rid;
  end if;
  return jsonb_build_object('request_id', rid, 'status', 'pending');
end;
$$;

-- تأیید یا رد درخواست توسط راننده
create or replace function public.decide_request(p_request uuid, p_approve boolean)
returns jsonb language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); tid uuid; t public.trips; r public.trip_requests;
begin
  if uid is null then raise exception 'login_required' using errcode = 'P0001'; end if;
  select trip_id into tid from public.trip_requests where id = p_request;
  if tid is null then raise exception 'not_found' using errcode = 'P0001'; end if;
  select * into t from public.trips where id = tid for update;
  if t.driver_id is distinct from uid then raise exception 'not_found' using errcode = 'P0001'; end if;
  select * into r from public.trip_requests where id = p_request for update;
  if r.status <> 'pending' then raise exception 'already_decided' using errcode = 'P0001'; end if;
  if t.status <> 'open' then raise exception 'trip_not_available' using errcode = 'P0001'; end if;
  if p_approve is true then
    if t.seats_taken + r.seats > t.capacity then raise exception 'not_enough_seats' using errcode = 'P0001'; end if;
    update public.trips set seats_taken = seats_taken + r.seats where id = t.id;
    update public.trip_requests set status = 'approved', decided_at = now() where id = r.id;
    return jsonb_build_object('status', 'approved');
  end if;
  update public.trip_requests set status = 'rejected', decided_at = now() where id = r.id;
  return jsonb_build_object('status', 'rejected');
end;
$$;

-- لغو درخواست توسط خود مسافر
create or replace function public.cancel_request(p_request uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); tid uuid; r public.trip_requests;
begin
  if uid is null then raise exception 'login_required' using errcode = 'P0001'; end if;
  select trip_id into tid from public.trip_requests where id = p_request and passenger_id = uid;
  if tid is null then raise exception 'not_found' using errcode = 'P0001'; end if;
  perform 1 from public.trips where id = tid for update;
  select * into r from public.trip_requests where id = p_request for update;
  if r.status not in ('pending','approved') then raise exception 'already_decided' using errcode = 'P0001'; end if;
  if r.status = 'approved' then
    update public.trips set seats_taken = greatest(0, seats_taken - r.seats) where id = tid;
  end if;
  update public.trip_requests set status = 'cancelled', decided_at = now() where id = r.id;
  return jsonb_build_object('status', 'cancelled');
end;
$$;

-- لغو سفر توسط راننده
create or replace function public.cancel_trip(p_trip uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); t public.trips;
begin
  if uid is null then raise exception 'login_required' using errcode = 'P0001'; end if;
  select * into t from public.trips where id = p_trip and driver_id = uid for update;
  if not found then raise exception 'not_found' using errcode = 'P0001'; end if;
  update public.trips set status = 'cancelled' where id = t.id;
  update public.trip_requests set status = 'cancelled', decided_at = now()
    where trip_id = t.id and status in ('pending','approved');
  return jsonb_build_object('status', 'cancelled');
end;
$$;

-- درخواست‌های خود مسافر. شماره‌ی راننده فقط برای درخواست تأییدشده‌ی سفر فعال برمی‌گردد.
create or replace function public.my_requests()
returns jsonb language sql security definer set search_path = public stable as $$
  select coalesce(jsonb_agg(x order by (x->>'created_at') desc), '[]'::jsonb) from (
    select jsonb_build_object(
      'request_id', r.id, 'trip_id', t.id, 'status', r.status, 'seats', r.seats, 'created_at', r.created_at,
      'origin', t.origin, 'destination', t.destination, 'trip_date', t.trip_date, 'depart_minute', t.depart_minute,
      'price', t.price, 'trip_status', t.status, 'driver_name', t.driver_name, 'car', t.car, 'meet', t.meet,
      'driver_phone', case when r.status = 'approved' and t.status = 'open' then dp.phone end,
      'driver_verified', case when r.status = 'approved' and t.status = 'open' then dp.phone_verified end
    ) as x
    from public.trip_requests r
    join public.trips t on t.id = r.trip_id
    left join public.profiles dp on dp.id = t.driver_id
    where r.passenger_id = auth.uid() and auth.uid() is not null
    order by r.created_at desc limit 50
  ) q
$$;

-- درخواست‌هایی که برای سفرهای خود راننده آمده. شماره‌ی مسافر فقط بعد از تأیید.
create or replace function public.my_trip_requests()
returns jsonb language sql security definer set search_path = public stable as $$
  select coalesce(jsonb_agg(x order by (x->>'created_at') desc), '[]'::jsonb) from (
    select jsonb_build_object(
      'request_id', r.id, 'trip_id', t.id, 'status', r.status, 'seats', r.seats, 'created_at', r.created_at,
      'passenger_name', pp.name,
      'passenger_phone', case when r.status = 'approved' and t.status = 'open' then pp.phone end,
      'passenger_verified', case when r.status = 'approved' and t.status = 'open' then pp.phone_verified end
    ) as x
    from public.trip_requests r
    join public.trips t on t.id = r.trip_id
    left join public.profiles pp on pp.id = r.passenger_id
    where t.driver_id = auth.uid() and auth.uid() is not null
    order by r.created_at desc limit 200
  ) q
$$;

-- فقط کاربر واردشده می‌تواند توابع را صدا بزند.
revoke all on function public.save_profile(text, text)      from public, anon;
revoke all on function public.request_seat(uuid, int)       from public, anon;
revoke all on function public.decide_request(uuid, boolean) from public, anon;
revoke all on function public.cancel_request(uuid)          from public, anon;
revoke all on function public.cancel_trip(uuid)             from public, anon;
revoke all on function public.my_requests()                 from public, anon;
revoke all on function public.my_trip_requests()            from public, anon;
grant execute on function public.save_profile(text, text)      to authenticated;
grant execute on function public.request_seat(uuid, int)       to authenticated;
grant execute on function public.decide_request(uuid, boolean) to authenticated;
grant execute on function public.cancel_request(uuid)          to authenticated;
grant execute on function public.cancel_trip(uuid)             to authenticated;
grant execute on function public.my_requests()                 to authenticated;
grant execute on function public.my_trip_requests()            to authenticated;
grant execute on function public.tehran_today(), public.tehran_minute() to anon, authenticated;
