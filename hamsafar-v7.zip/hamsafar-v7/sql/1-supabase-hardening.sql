-- =====================================================================
-- هم‌سفر: تقویت امنیت و پاک‌سازی (وصله‌ی نسخه‌ی ۲)
-- این فایل را بعد از supabase-setup.sql در SQL Editor اجرا کنید.
-- جدولی حذف یا بازسازی نمی‌کند و داده‌ای را پاک نمی‌کند. فقط توابع و تریگرها را به‌روز می‌کند.
-- اجرای دوباره‌ی آن بی‌خطر است.
--
-- چه چیزهایی عوض می‌شود:
--  ۱) سقف ثبت سفر «برای هر کاربر» است، نه برای کل سایت: یک مزاحم دیگر نمی‌تواند ثبت سفر را برای همه ببندد.
--  ۲) سقف ساعتی برای درخواست صندلی هر کاربر.
--  ۳) تابع پاک‌سازی (سفرهای قدیمی، کدهای پیامکی، حساب‌های ناشناس بی‌استفاده)؛ فقط خود شما آن را اجرا می‌کنید.
-- =====================================================================

-- ۱) محدودیت ثبت سفر: برای هر راننده و یک سقف کلی بزرگ برای محافظت از پایگاه داده
create or replace function public.trips_throttle()
returns trigger language plpgsql security definer set search_path = public as $$
declare uid uuid := coalesce(new.driver_id, auth.uid());
begin
  if uid is not null then
    if (select count(*) from public.trips
          where driver_id = uid and created_at > now() - interval '10 minutes') >= 10 then
      raise exception 'too_many_trips_recently' using errcode = 'P0001';
    end if;
    if (select count(*) from public.trips
          where driver_id = uid and created_at > now() - interval '24 hours') >= 40 then
      raise exception 'trip_daily_limit' using errcode = 'P0001';
    end if;
  end if;
  -- سقف ایمنی سراسری (بسیار بالاتر از مصرف عادی)
  if (select count(*) from public.trips where created_at > now() - interval '10 minutes') >= 500 then
    raise exception 'too_many_trips_recently' using errcode = 'P0001';
  end if;
  if (select count(*) from public.trips) >= 20000 then
    raise exception 'trip_table_full' using errcode = 'P0001';
  end if;
  return new;
end;
$$;
-- تریگر trips_throttle_trg از نسخه‌ی ۲ همین تابع را صدا می‌زند و دوباره ساخته نمی‌شود.

-- ۲) محدودیت درخواست صندلی: حداکثر ۳۰ درخواست جدید در ساعت برای هر مسافر
create or replace function public.requests_throttle()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if (select count(*) from public.trip_requests
        where passenger_id = new.passenger_id and created_at > now() - interval '1 hour') >= 30 then
    raise exception 'request_rate_limited' using errcode = 'P0001';
  end if;
  return new;
end;
$$;

drop trigger if exists requests_throttle_trg on public.trip_requests;
create trigger requests_throttle_trg before insert on public.trip_requests
  for each row execute function public.requests_throttle();

-- ۳) پاک‌سازی. فقط شما (از SQL Editor یا زمان‌بندی) آن را اجرا می‌کنید؛ کاربران سایت نمی‌توانند.
--    - سفرهایی که بیش از ۳۰ روز از تاریخشان گذشته (درخواست‌های آن‌ها هم پاک می‌شود)
--    - کدهای پیامکی قدیمی‌تر از یک روز
--    - حساب‌های ناشناسی که بیش از ۳ روز پیش ساخته شده و هرگز نمایه نساخته‌اند
create or replace function public.cleanup_old_data()
returns jsonb language plpgsql security definer set search_path = public as $$
declare n_trips int := 0; n_otp int := 0; n_users int := 0;
begin
  delete from public.trips where trip_date < public.tehran_today() - 30;
  get diagnostics n_trips = row_count;
  delete from public.otp_codes where created_at < now() - interval '1 day';
  get diagnostics n_otp = row_count;
  if exists (select 1 from information_schema.columns
              where table_schema = 'auth' and table_name = 'users' and column_name = 'is_anonymous') then
    execute $q$
      delete from auth.users u
       where u.is_anonymous and u.created_at < now() - interval '3 days'
         and not exists (select 1 from public.profiles p where p.id = u.id)
    $q$;
    get diagnostics n_users = row_count;
  end if;
  return jsonb_build_object('trips_deleted', n_trips, 'otp_deleted', n_otp, 'anonymous_users_deleted', n_users);
end;
$$;
revoke all on function public.cleanup_old_data() from public, anon, authenticated;

-- ---------------------------------------------------------------------
-- اجرای پاک‌سازی (اختیاری، دستی): select public.cleanup_old_data();
--
-- اجرای خودکار هر شب (اختیاری): ابتدا در Supabase، Database ← Extensions، افزونه‌ی pg_cron را روشن کنید،
-- بعد خط زیر را بدون // جلوی آن اجرا کنید:
--   select cron.schedule('hamsafar-cleanup', '30 0 * * *', $$select public.cleanup_old_data()$$);
-- ---------------------------------------------------------------------
