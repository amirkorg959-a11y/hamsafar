-- =====================================================================
--  هم‌سفر — تبلیغات و معرفی کسب‌وکارها (مرحله‌ی ۷)
--  بعد از supabase-admin.sql اجرا می‌شود (از نگهبان مدیر و تاریخچه‌ی آن استفاده می‌کند).
--  چند بار اجرا کردنش بی‌خطر است. هیچ جدول قبلی تغییر نمی‌کند؛ فقط جدول «ads» ساخته می‌شود.
--
--  • تبلیغ جدید همیشه «pending» (در انتظار) است و تا تأیید مدیر برای عموم دیده نمی‌شود.
--  • کاربران مستقیم به جدول دسترسی ندارند؛ فقط از راه توابع زیر.
--  • ثبت تبلیغ فعلاً رایگان است. ستون‌های tier / featured_until / paid_amount برای
--    «تبلیغ ویژه و پولی» در آینده آماده‌اند (فعلاً فقط مدیر می‌تواند ویژه کند).
--  • تصویر کوچک‌شده (حداکثر حدود ۶۵ کیلوبایت) داخل خود جدول ذخیره می‌شود تا نیازی به Storage نباشد.
-- =====================================================================

create table if not exists public.ads (
  id             uuid primary key default gen_random_uuid(),
  owner_id       uuid not null references auth.users(id) on delete cascade,
  business_name  text not null check (char_length(btrim(business_name)) between 2 and 60 and business_name !~ '[<>]'),
  contact_name   text not null check (char_length(btrim(contact_name)) between 2 and 40 and contact_name !~ '[<>]'),
  phone          text not null check (phone ~ '^0[0-9]{9,10}$'),
  description    text not null check (char_length(btrim(description)) between 10 and 400 and description !~ '[<>]'),
  link           text check (link is null or (link ~ '^https://[^[:space:]<>"'']+$' and char_length(link) <= 200)),
  image_data     text check (image_data is null or (image_data ~ '^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$' and char_length(image_data) <= 90000)),
  status         text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  reject_reason  text,
  tier           text not null default 'free' check (tier in ('free', 'featured')),   -- آینده: تبلیغ ویژه/پولی
  featured_until timestamptz,
  paid_amount    int  not null default 0 check (paid_amount >= 0),                    -- آینده: مبلغ پرداخت‌شده (تومان)
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),
  decided_at     timestamptz,
  decided_by     uuid
);
create index if not exists ads_status_idx on public.ads (status, decided_at desc);
create index if not exists ads_owner_idx  on public.ads (owner_id, created_at desc);
alter table public.ads enable row level security;
revoke all on public.ads from anon, authenticated;     -- بدون هیچ سیاست؛ فقط از راه توابع

-- اعتبارسنجی مشترک (کاربر و مدیر)
create or replace function public._ad_validate(p_business text, p_contact text, p_phone text, p_description text, p_link text, p_image text)
returns void language plpgsql immutable as $$
begin
  if p_business is null or char_length(btrim(p_business)) not between 2 and 60 or p_business ~ '[<>]' then raise exception 'bad_ad_business' using errcode = 'P0001'; end if;
  if p_contact is null or char_length(btrim(p_contact)) not between 2 and 40 or p_contact ~ '[<>]' then raise exception 'bad_ad_contact' using errcode = 'P0001'; end if;
  if p_phone is null or p_phone !~ '^0[0-9]{9,10}$' then raise exception 'bad_ad_phone' using errcode = 'P0001'; end if;
  if p_description is null or char_length(btrim(p_description)) not between 10 and 400 or p_description ~ '[<>]' then raise exception 'bad_ad_description' using errcode = 'P0001'; end if;
  if p_link is not null and p_link <> '' and (p_link !~ '^https://[^[:space:]<>"'']+$' or char_length(p_link) > 200) then raise exception 'bad_ad_link' using errcode = 'P0001'; end if;
  if p_image is not null and p_image <> '' and (p_image !~ '^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$' or char_length(p_image) > 90000) then raise exception 'bad_ad_image' using errcode = 'P0001'; end if;
end;
$$;
revoke all on function public._ad_validate(text, text, text, text, text, text) from public, anon, authenticated;

-- ثبت تبلیغ (رایگان) → همیشه «در انتظار تأیید»
create or replace function public.submit_ad(p_business text, p_contact text, p_phone text, p_description text, p_link text default null, p_image text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); p record; rid uuid; b text := btrim(p_business);
begin
  if uid is null then raise exception 'login_required' using errcode = 'P0001'; end if;
  select name, phone, phone_verified into p from public.profiles where id = uid;
  if not found or p.name is null or p.phone is null then raise exception 'profile_required' using errcode = 'P0001'; end if;
  if public.require_verified() and not coalesce(p.phone_verified, false) then raise exception 'phone_not_verified' using errcode = 'P0001'; end if;
  perform public._ad_validate(p_business, p_contact, p_phone, p_description, p_link, p_image);
  if (select count(*) from public.ads where owner_id = uid and status = 'pending') >= 3 then raise exception 'too_many_pending_ads' using errcode = 'P0001'; end if;
  if (select count(*) from public.ads where owner_id = uid and created_at > now() - interval '24 hours') >= 5 then raise exception 'ad_daily_limit' using errcode = 'P0001'; end if;
  if (select count(*) from public.ads where status = 'pending') >= 500 then raise exception 'ads_busy' using errcode = 'P0001'; end if;
  if exists (select 1 from public.ads where owner_id = uid and lower(business_name) = lower(b) and status in ('pending', 'approved')) then raise exception 'duplicate_ad' using errcode = 'P0001'; end if;
  insert into public.ads(owner_id, business_name, contact_name, phone, description, link, image_data)
  values (uid, b, btrim(p_contact), p_phone, btrim(p_description), nullif(btrim(coalesce(p_link, '')), ''), nullif(p_image, ''))
  returning id into rid;
  return jsonb_build_object('id', rid, 'status', 'pending');
end;
$$;

-- تبلیغ‌های خود کاربر
create or replace function public.my_ads() returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(x order by (x->>'created_at') desc), '[]'::jsonb) from (
    select jsonb_build_object('id', a.id, 'business_name', a.business_name, 'description', a.description, 'phone', a.phone, 'link', a.link,
      'status', a.status, 'reject_reason', a.reject_reason, 'tier', a.tier, 'created_at', a.created_at, 'has_image', a.image_data is not null) as x
    from public.ads a where a.owner_id = auth.uid() and auth.uid() is not null order by a.created_at desc limit 20
  ) q
$$;

create or replace function public.delete_my_ad(p_ad uuid) returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'login_required' using errcode = 'P0001'; end if;
  delete from public.ads where id = p_ad and owner_id = auth.uid();
  if not found then raise exception 'not_found' using errcode = 'P0001'; end if;
  return jsonb_build_object('deleted', true);
end;
$$;

-- نمایش عمومی: فقط تأییدشده‌ها؛ بدون نام مسئول و بدون مالک
create or replace function public.public_ads(p_limit int default 30) returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(x order by (x->>'rank')::int, (x->>'decided_at') desc), '[]'::jsonb) from (
    select jsonb_build_object('id', a.id, 'business_name', a.business_name, 'description', a.description, 'phone', a.phone,
      'link', a.link, 'image_data', a.image_data, 'decided_at', a.decided_at,
      'featured', (a.tier = 'featured' and (a.featured_until is null or a.featured_until > now())),
      'rank', case when a.tier = 'featured' and (a.featured_until is null or a.featured_until > now()) then 0 else 1 end) as x
    from public.ads a where a.status = 'approved'
    order by case when a.tier = 'featured' and (a.featured_until is null or a.featured_until > now()) then 0 else 1 end, a.decided_at desc
    limit least(greatest(coalesce(p_limit, 30), 1), 60)
  ) q
$$;

-- ---------- مدیر ----------
create or replace function public.admin_ads_counts() returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  perform public._admin_guard();
  return (select jsonb_build_object('pending', count(*) filter (where status = 'pending'), 'approved', count(*) filter (where status = 'approved'), 'rejected', count(*) filter (where status = 'rejected')) from public.ads);
end;
$$;

create or replace function public.admin_list_ads(p_status text default null, p_limit int default 50) returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  perform public._admin_guard();
  return (select coalesce(jsonb_agg(x order by (x->>'created_at') desc), '[]'::jsonb) from (
    select jsonb_build_object('id', a.id, 'business_name', a.business_name, 'contact_name', a.contact_name, 'phone', a.phone,
      'description', a.description, 'link', a.link, 'image_data', a.image_data, 'status', a.status, 'reject_reason', a.reject_reason,
      'tier', a.tier, 'featured_until', a.featured_until, 'paid_amount', a.paid_amount, 'created_at', a.created_at, 'decided_at', a.decided_at,
      'owner_name', p.name) as x
    from public.ads a left join public.profiles p on p.id = a.owner_id
    where (p_status is null or a.status = p_status)
    order by a.created_at desc limit least(greatest(coalesce(p_limit, 50), 1), 100)
  ) q);
end;
$$;

create or replace function public.admin_ad_decide(p_ad uuid, p_decision text, p_reason text default null) returns jsonb language plpgsql security definer set search_path = public as $$
declare a public.ads; ns text;
begin
  perform public._admin_guard();
  if p_decision not in ('approve', 'reject') then raise exception 'bad_decision' using errcode = 'P0001'; end if;
  if p_decision = 'reject' and char_length(btrim(coalesce(p_reason, ''))) < 3 then raise exception 'reason_required' using errcode = 'P0001'; end if;
  select * into a from public.ads where id = p_ad for update;
  if not found then raise exception 'not_found' using errcode = 'P0001'; end if;
  ns := case when p_decision = 'approve' then 'approved' else 'rejected' end;
  update public.ads set status = ns, decided_at = now(), decided_by = auth.uid(), updated_at = now(),
         reject_reason = case when ns = 'rejected' then left(btrim(p_reason), 200) else null end where id = a.id;
  perform public._audit('ad_' || p_decision, 'ad', a.id::text, jsonb_build_object('business', a.business_name, 'old_status', a.status, 'reason', left(btrim(coalesce(p_reason, '')), 200)));
  return jsonb_build_object('status', ns);
end;
$$;

create or replace function public.admin_update_ad(p_ad uuid, p_business text, p_description text, p_phone text, p_link text default null, p_remove_image boolean default false)
returns jsonb language plpgsql security definer set search_path = public as $$
declare a public.ads;
begin
  perform public._admin_guard();
  select * into a from public.ads where id = p_ad for update;
  if not found then raise exception 'not_found' using errcode = 'P0001'; end if;
  perform public._ad_validate(p_business, a.contact_name, p_phone, p_description, p_link, null);
  update public.ads set business_name = btrim(p_business), description = btrim(p_description), phone = p_phone,
         link = nullif(btrim(coalesce(p_link, '')), ''), image_data = case when p_remove_image then null else image_data end, updated_at = now()
   where id = a.id;
  perform public._audit('ad_edit', 'ad', a.id::text, jsonb_build_object('old_business', a.business_name, 'new_business', btrim(p_business), 'removed_image', coalesce(p_remove_image, false)));
  return jsonb_build_object('updated', true);
end;
$$;

create or replace function public.admin_delete_ad(p_ad uuid, p_reason text) returns jsonb language plpgsql security definer set search_path = public as $$
declare a public.ads;
begin
  perform public._admin_guard();
  if char_length(btrim(coalesce(p_reason, ''))) < 3 then raise exception 'reason_required' using errcode = 'P0001'; end if;
  select * into a from public.ads where id = p_ad for update;
  if not found then raise exception 'not_found' using errcode = 'P0001'; end if;
  delete from public.ads where id = a.id;
  perform public._audit('ad_delete', 'ad', a.id::text, jsonb_build_object('business', a.business_name, 'status', a.status, 'reason', left(btrim(p_reason), 200)));
  return jsonb_build_object('deleted', true);
end;
$$;

-- آینده: ویژه/پولی کردن (فعلاً دستی توسط مدیر؛ اتصال به درگاه بعداً)
create or replace function public.admin_set_ad_tier(p_ad uuid, p_tier text, p_until timestamptz default null, p_paid int default 0)
returns jsonb language plpgsql security definer set search_path = public as $$
declare a public.ads;
begin
  perform public._admin_guard();
  if p_tier not in ('free', 'featured') then raise exception 'bad_tier' using errcode = 'P0001'; end if;
  if p_paid is null or p_paid < 0 then raise exception 'bad_paid' using errcode = 'P0001'; end if;
  select * into a from public.ads where id = p_ad for update;
  if not found then raise exception 'not_found' using errcode = 'P0001'; end if;
  update public.ads set tier = p_tier, featured_until = case when p_tier = 'featured' then p_until else null end, paid_amount = p_paid, updated_at = now() where id = a.id;
  perform public._audit('ad_tier', 'ad', a.id::text, jsonb_build_object('business', a.business_name, 'tier', p_tier, 'until', p_until, 'paid_amount', p_paid));
  return jsonb_build_object('tier', p_tier);
end;
$$;

-- دسترسی‌ها
revoke all on function public.submit_ad(text, text, text, text, text, text), public.my_ads(), public.delete_my_ad(uuid), public.public_ads(int),
  public.admin_ads_counts(), public.admin_list_ads(text, int), public.admin_ad_decide(uuid, text, text),
  public.admin_update_ad(uuid, text, text, text, text, boolean), public.admin_delete_ad(uuid, text), public.admin_set_ad_tier(uuid, text, timestamptz, int)
  from public, anon;
grant execute on function public.public_ads(int) to anon, authenticated;
grant execute on function public.submit_ad(text, text, text, text, text, text), public.my_ads(), public.delete_my_ad(uuid),
  public.admin_ads_counts(), public.admin_list_ads(text, int), public.admin_ad_decide(uuid, text, text),
  public.admin_update_ad(uuid, text, text, text, text, boolean), public.admin_delete_ad(uuid, text), public.admin_set_ad_tier(uuid, text, timestamptz, int)
  to authenticated;
