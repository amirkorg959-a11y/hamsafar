-- =====================================================================
-- هم‌سفر: حالت «ورود پیامکی اجباری» (وصله‌ی نسخه‌ی ۲٫۲)
-- بعد از supabase-setup.sql (و در صورت اجرا، supabase-hardening.sql) اجرا کنید.
-- جدولی حذف یا بازسازی نمی‌کند و داده‌ای پاک نمی‌کند. اجرای دوباره‌اش بی‌خطر است.
--
-- این فایل یک «کلید» (در جدول app_settings) می‌سازد که پیش‌فرضش خاموش است:
--   خاموش: رفتار فعلی (ورود آزمایشی هم کار می‌کند)
--   روشن:  فقط کسی که شماره‌اش با پیامک تأیید شده می‌تواند سفر ثبت کند یا صندلی بخواهد
-- پس تا ورود پیامکی را راه نینداخته‌اید، چیزی خراب نمی‌شود.
-- =====================================================================

create table if not exists public.app_settings (
  key   text primary key,
  value text not null
);
alter table public.app_settings enable row level security;
revoke all on public.app_settings from anon, authenticated;   -- بدون سیاست: فقط مالک (شما) می‌خواند و می‌نویسد
insert into public.app_settings(key, value) values ('require_verified_phone', 'false')
  on conflict (key) do nothing;

create or replace function public.require_verified()
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select value from public.app_settings where key = 'require_verified_phone'), 'false') = 'true'
$$;
revoke all on function public.require_verified() from public, anon, authenticated;

-- ثبت سفر: در حالت اجباری فقط شماره‌ی تأییدشده
create or replace function public.trips_before_insert()
returns trigger language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); p record;
begin
  if uid is null then raise exception 'login_required' using errcode = 'P0001'; end if;
  select name, phone, phone_verified into p from public.profiles where id = uid;
  if not found or p.name is null or p.phone is null then
    raise exception 'profile_required' using errcode = 'P0001';
  end if;
  if public.require_verified() and not coalesce(p.phone_verified, false) then
    raise exception 'phone_not_verified' using errcode = 'P0001';
  end if;
  if (select count(*) from public.trips
        where driver_id = uid and status = 'open' and trip_date >= public.tehran_today()) >= 10 then
    raise exception 'too_many_open_trips' using errcode = 'P0001';
  end if;
  new.driver_id   := uid;
  new.driver_name := p.name;
  new.status      := 'open';
  new.seats_taken := 0;
  return new;
end;
$$;

-- درخواست صندلی: در حالت اجباری فقط شماره‌ی تأییدشده
create or replace function public.request_seat(p_trip uuid, p_seats int)
returns jsonb language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); t public.trips; r public.trip_requests; p record; rid uuid;
begin
  if uid is null then raise exception 'login_required' using errcode = 'P0001'; end if;
  select name, phone, phone_verified into p from public.profiles where id = uid;
  if not found or p.name is null or p.phone is null then raise exception 'profile_required' using errcode = 'P0001'; end if;
  if public.require_verified() and not coalesce(p.phone_verified, false) then
    raise exception 'phone_not_verified' using errcode = 'P0001';
  end if;
  select * into t from public.trips where id = p_trip for update;
  if not found or t.status <> 'open' or t.driver_id is null
     or t.trip_date < public.tehran_today()
     or (t.trip_date = public.tehran_today() and t.depart_minute <= public.tehran_minute()) then
    raise exception 'trip_not_available' using errcode = 'P0001';
  end if;
  if t.driver_id = uid then raise exception 'own_trip' using errcode = 'P0001'; end if;
  if p_seats is null or p_seats < 1 or p_seats > t.capacity - t.seats_taken then
    raise exception 'not_enough_seats' using errcode = 'P0001';
  end if;
  if (select count(*) from public.trip_requests where passenger_id = uid and status = 'pending') >= 10 then
    raise exception 'too_many_requests' using errcode = 'P0001';
  end if;
  select * into r from public.trip_requests where trip_id = p_trip and passenger_id = uid for update;
  if found then
    if r.status in ('pending','approved') then raise exception 'already_requested' using errcode = 'P0001'; end if;
    if r.status = 'rejected' then raise exception 'already_rejected' using errcode = 'P0001'; end if;
    update public.trip_requests set seats = p_seats, status = 'pending', decided_at = null, created_at = now()
      where id = r.id returning id into rid;
  else
    insert into public.trip_requests(trip_id, passenger_id, seats) values (p_trip, uid, p_seats) returning id into rid;
  end if;
  return jsonb_build_object('request_id', rid, 'status', 'pending');
end;
$$;

-- ---------------------------------------------------------------------
-- روشن کردن حالت اجباری (فقط بعد از اینکه ورود پیامکی را راه انداختید و خودتان یک بار امتحانش کردید):
--   update public.app_settings set value = 'true' where key = 'require_verified_phone';
-- خاموش کردن (برگشت):
--   update public.app_settings set value = 'false' where key = 'require_verified_phone';
-- وضعیت فعلی:
--   select * from public.app_settings;
-- ---------------------------------------------------------------------
