-- =====================================================================
-- هم‌سفر: سیستم کمیسیون رانندگان با درگاه زرین‌پال (نسخه‌ی ۳٫۰)
-- این فایل را در Supabase، SQL Editor اجرا کنید. تا وقتی «enabled» را روشن نکنید هیچ کمیسیونی ساخته نمی‌شود.
-- قواعد: کمیسیون ۵٪ | کرایه مستقیم به راننده | کمیسیون بعد از انجام سفر | پرداخت جداگانه برای هر سفر
--
-- اصول طراحی:
--  * هیچ جدول فعلی (trips, profiles, trip_requests, otp_codes, app_settings) تغییر نمی‌کند.
--    فقط جدول‌های تازه ساخته می‌شوند. یک تابع موجود (cancel_trip) نسخه‌ی محافظت‌شده می‌گیرد.
--  * هر سفر حداکثر یک کمیسیون دارد (کلید یکتا روی trip_id). حتی اگر سفر بعداً پاک شود، سابقه می‌ماند.
--  * همه‌ی مبلغ‌ها «تومان» و عدد صحیح‌اند. تبدیل به ریال فقط در تابع سرور درگاه انجام می‌شود.
--  * مرورگر هرگز مبلغ یا وضعیت پرداخت را نمی‌نویسد. وضعیت «پرداخت‌شده» فقط با توابعی عوض می‌شود که
--    فقط نقش service_role (تابع سرور بعد از تأیید مستقیم درگاه) می‌تواند صدا بزند.
--  * کلید اصلی خاموش است (enabled = false) تا وقتی خودتان روشن کنید هیچ کمیسیونی ساخته نمی‌شود.
-- اجرای دوباره‌اش بی‌خطر است.
-- =====================================================================

-- ۱) تنظیمات (یک ردیف). فقط شما از SQL Editor عوضش می‌کنید.
create table if not exists public.commission_settings (
  id                  boolean primary key default true check (id),
  enabled             boolean  not null default false,
  rate_bps            int      not null default 500  check (rate_bps between 0 and 3000),   -- ۵۰۰ = ۵٪
  min_amount          int      not null default 1000 check (min_amount >= 0),                -- تومان؛ کمیسیون کمتر از این بخشوده می‌شود (درگاه حداقل مبلغ دارد؛ با زرین‌پال تأیید کنید)
  grace_days          int      not null default 3    check (grace_days between 0 and 60),    -- مهلت پرداخت پس از انجام سفر
  auto_complete_hours int      not null default 24   check (auto_complete_hours between 1 and 240),
  updated_at          timestamptz not null default now()
);
insert into public.commission_settings(id) values (true) on conflict (id) do nothing;

-- ۲) مدیران درآمد (شناسه‌ی کاربری خودتان را اینجا اضافه می‌کنید)
create table if not exists public.app_admins (
  user_id    uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

-- ۳) کمیسیون هر سفر (یک ردیف به‌ازای هر سفر؛ همان «بدهی راننده»)
create table if not exists public.commissions (
  id               uuid primary key default gen_random_uuid(),
  trip_id          uuid not null,                       -- عمداً بدون کلید خارجی: پاک‌سازی سفر، سابقه را پاک نکند
  driver_id        uuid not null references auth.users(id) on delete restrict,
  trip_origin      text not null,                       -- عکس لحظه‌ای سفر
  trip_destination text not null,
  trip_date        date not null,
  depart_minute    smallint not null,
  seats_total      smallint not null check (seats_total >= 1),
  fare_per_seat    int not null check (fare_per_seat >= 0),
  gross_amount     int not null check (gross_amount >= 0),   -- مجموع کرایه‌ی مسافران تأییدشده
  rate_bps         int not null,                              -- نرخ لحظه‌ی ثبت (تغییر نرخ، سابقه را عوض نمی‌کند)
  amount           int not null check (amount >= 0),          -- کمیسیون
  status           text not null default 'due' check (status in ('due','paid','waived')),
  source           text not null check (source in ('driver','auto','admin')),
  completed_at     timestamptz not null default now(),
  due_at           timestamptz not null,
  paid_at          timestamptz,
  waived_at        timestamptz,
  waived_by        uuid,
  waive_reason     text,
  constraint commissions_trip_uq unique (trip_id)
);
create index if not exists commissions_driver_idx on public.commissions (driver_id, status);
create index if not exists commissions_status_due_idx on public.commissions (status, due_at);

-- ۴) تلاش‌های پرداخت (برای هر کمیسیون ممکن است چند تلاش باشد؛ فقط یکی می‌تواند موفق شود)
create table if not exists public.commission_payments (
  id             uuid primary key default gen_random_uuid(),
  commission_id  uuid not null references public.commissions(id) on delete restrict,
  driver_id      uuid not null,
  gateway        text not null,
  amount         int  not null check (amount > 0),     -- از پایگاه داده گرفته می‌شود، نه از مرورگر
  authority      text unique,                           -- شناسه‌ی تراکنش درگاه
  status         text not null default 'initiated' check (status in ('initiated','paid','failed','canceled','duplicate')),
  ref_id         text,
  card_pan       text,                                  -- فقط ماسک‌شده، مثل 6037****1234
  failure_reason text,
  created_at     timestamptz not null default now(),
  verified_at    timestamptz
);
create unique index if not exists commission_one_paid_uq on public.commission_payments (commission_id) where status = 'paid';
create index if not exists commission_payments_commission_idx on public.commission_payments (commission_id);

-- ۵) دفتر رویدادها برای ردگیری (فقط مدیر می‌خواند)
create table if not exists public.payment_events (
  id         bigint generated always as identity primary key,
  payment_id uuid references public.commission_payments(id) on delete set null,
  kind       text not null,
  ok         boolean,
  detail     jsonb,
  created_at timestamptz not null default now()
);

-- ۶) قفل ایمنی
alter table public.commission_settings enable row level security;
alter table public.app_admins          enable row level security;
alter table public.commissions         enable row level security;
alter table public.commission_payments enable row level security;
alter table public.payment_events      enable row level security;
revoke all on public.commission_settings, public.app_admins, public.commissions,
              public.commission_payments, public.payment_events from anon, authenticated;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select auth.uid() is not null and exists (select 1 from public.app_admins where user_id = auth.uid())
$$;
revoke all on function public.is_admin() from public, anon;
grant execute on function public.is_admin() to authenticated;

grant select on public.commissions, public.commission_payments to authenticated;
drop policy if exists "commissions_select_own_or_admin" on public.commissions;
create policy "commissions_select_own_or_admin" on public.commissions
  for select to authenticated using (driver_id = auth.uid() or public.is_admin());
drop policy if exists "payments_select_own_or_admin" on public.commission_payments;
create policy "payments_select_own_or_admin" on public.commission_payments
  for select to authenticated using (driver_id = auth.uid() or public.is_admin());
grant select on public.payment_events to authenticated;
drop policy if exists "events_select_admin" on public.payment_events;
create policy "events_select_admin" on public.payment_events
  for select to authenticated using (public.is_admin());
-- هیچ سیاست نوشتن (insert/update/delete) برای کاربران وجود ندارد.

-- ۷) اطلاعات عمومی نرخ (برای نمایش به راننده)
create or replace function public.commission_info()
returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_build_object('enabled', enabled, 'rate_bps', rate_bps, 'grace_days', grace_days, 'min_amount', min_amount)
  from public.commission_settings where id
$$;
revoke all on function public.commission_info() from public, anon;
grant execute on function public.commission_info() to authenticated;

-- ۸) ساخت کمیسیون (داخلی؛ فقط توابع زیر آن را صدا می‌زنند). جلوگیری از ثبت دوباره با کلید یکتا.
create or replace function public._create_commission(t public.trips, p_seats int, src text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare s public.commission_settings; gross bigint; amt int; st text := 'due'; why text; c public.commissions; made boolean := false;
begin
  select * into s from public.commission_settings where id;
  gross := p_seats::bigint * t.price;
  amt   := ((gross * s.rate_bps + 5000) / 10000)::int;           -- گرد کردن به نزدیک‌ترین تومان (نیم به بالا)
  if amt <= 0 or amt < s.min_amount then st := 'waived'; why := 'below_min'; end if;
  insert into public.commissions(trip_id, driver_id, trip_origin, trip_destination, trip_date, depart_minute,
        seats_total, fare_per_seat, gross_amount, rate_bps, amount, status, source, due_at, waived_at, waive_reason)
  values (t.id, t.driver_id, t.origin, t.destination, t.trip_date, t.depart_minute,
        p_seats, t.price, gross::int, s.rate_bps, amt, st, src, now() + make_interval(days => s.grace_days),
        case when st = 'waived' then now() end, why)
  on conflict (trip_id) do nothing
  returning * into c;
  if found then made := true; else select * into c from public.commissions where trip_id = t.id; end if;
  return jsonb_build_object('commission_id', c.id, 'amount', c.amount, 'status', c.status, 'created', made);
end;
$$;
revoke all on function public._create_commission(public.trips, int, text) from public, anon, authenticated;

-- ۹) راننده «سفر انجام شد» را می‌زند
create or replace function public.complete_trip(p_trip uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); s public.commission_settings; t public.trips; v_seats int;
begin
  if uid is null then raise exception 'login_required' using errcode = 'P0001'; end if;
  select * into s from public.commission_settings where id;
  if not s.enabled then raise exception 'commission_disabled' using errcode = 'P0001'; end if;
  select * into t from public.trips where id = p_trip and driver_id = uid for update;
  if not found then raise exception 'not_found' using errcode = 'P0001'; end if;
  if t.status <> 'open' then raise exception 'trip_not_available' using errcode = 'P0001'; end if;
  if t.trip_date > public.tehran_today()
     or (t.trip_date = public.tehran_today() and t.depart_minute > public.tehran_minute()) then
    raise exception 'trip_not_started' using errcode = 'P0001';
  end if;
  select coalesce(sum(r.seats), 0) into v_seats from public.trip_requests r where r.trip_id = t.id and r.status = 'approved';
  if v_seats = 0 then raise exception 'no_approved_passengers' using errcode = 'P0001'; end if;
  return public._create_commission(t, v_seats, 'driver');
end;
$$;
revoke all on function public.complete_trip(uuid) from public, anon;
grant execute on function public.complete_trip(uuid) to authenticated;

-- ۱۰) تکمیل خودکار: اگر راننده بعد از N ساعت از حرکت، سفر را تکمیل نکرده باشد (جلوگیری از فرار از کمیسیون)
create or replace function public.auto_complete_trips()
returns int language plpgsql security definer set search_path = public as $$
declare s public.commission_settings; t public.trips; v_seats int; n int := 0;
begin
  select * into s from public.commission_settings where id;
  if not s.enabled then return 0; end if;
  for t in
    select * from public.trips
     where status = 'open' and driver_id is not null
       and ((trip_date::timestamp + make_interval(mins => depart_minute)) at time zone 'Asia/Tehran')
           <= now() - make_interval(hours => s.auto_complete_hours)
       and not exists (select 1 from public.commissions c where c.trip_id = trips.id)
  loop
    select coalesce(sum(r.seats), 0) into v_seats from public.trip_requests r where r.trip_id = t.id and r.status = 'approved';
    if v_seats > 0 then perform public._create_commission(t, v_seats, 'auto'); n := n + 1; end if;
  end loop;
  return n;
end;
$$;
revoke all on function public.auto_complete_trips() from public, anon, authenticated;

-- ۱۱) نسخه‌ی محافظت‌شده‌ی لغو سفر: سفری که کمیسیون دارد دیگر لغو نمی‌شود (تابع موجود فقط یک شرط می‌گیرد)
create or replace function public.cancel_trip(p_trip uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); t public.trips;
begin
  if uid is null then raise exception 'login_required' using errcode = 'P0001'; end if;
  select * into t from public.trips where id = p_trip and driver_id = uid for update;
  if not found then raise exception 'not_found' using errcode = 'P0001'; end if;
  if exists (select 1 from public.commissions where trip_id = t.id) then
    raise exception 'trip_already_completed' using errcode = 'P0001';
  end if;
  update public.trips set status = 'cancelled' where id = t.id;
  update public.trip_requests set status = 'cancelled', decided_at = now()
    where trip_id = t.id and status in ('pending','approved');
  return jsonb_build_object('status', 'cancelled');
end;
$$;

-- ۱۲) سوابق کمیسیون خود راننده
create or replace function public.my_commissions()
returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(x order by (x->>'completed_at') desc), '[]'::jsonb) from (
    select jsonb_build_object(
      'commission_id', c.id, 'trip_id', c.trip_id, 'origin', c.trip_origin, 'destination', c.trip_destination,
      'trip_date', c.trip_date, 'depart_minute', c.depart_minute, 'seats', c.seats_total,
      'gross_amount', c.gross_amount, 'rate_bps', c.rate_bps, 'amount', c.amount, 'status', c.status,
      'completed_at', c.completed_at, 'due_at', c.due_at, 'paid_at', c.paid_at,
      'overdue', (c.status = 'due' and c.due_at < now()),
      'last_payment', (select jsonb_build_object('status', p.status, 'ref_id', p.ref_id, 'at', p.created_at)
                         from public.commission_payments p where p.commission_id = c.id order by p.created_at desc limit 1)
    ) as x
    from public.commissions c where c.driver_id = auth.uid() and auth.uid() is not null
    order by c.completed_at desc limit 200
  ) q
$$;
-- ۱۲-ب) سوابق «پرداخت‌های موفق» خود راننده (تلاش‌های ناموفق به راننده نشان داده نمی‌شود)
create or replace function public.my_payments()
returns jsonb language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(x order by (x->>'paid_at') desc), '[]'::jsonb) from (
    select jsonb_build_object(
      'payment_id', p.id, 'amount', p.amount, 'ref_id', p.ref_id,
      'card_last4', case when p.card_pan is null then null else right(regexp_replace(p.card_pan, '[^0-9]', '', 'g'), 4) end,
      'paid_at', coalesce(p.verified_at, p.created_at),
      'origin', c.trip_origin, 'destination', c.trip_destination, 'trip_date', c.trip_date
    ) as x
    from public.commission_payments p join public.commissions c on c.id = p.commission_id
    where p.driver_id = auth.uid() and auth.uid() is not null and p.status = 'paid'
    order by coalesce(p.verified_at, p.created_at) desc limit 100
  ) q
$$;
revoke all on function public.my_payments() from public, anon;
grant execute on function public.my_payments() to authenticated;

revoke all on function public.my_commissions() from public, anon;
grant execute on function public.my_commissions() to authenticated;

-- ۱۳) توابع پرداخت: فقط service_role (تابع سرور بعد از تأیید مستقیم درگاه). مرورگر نمی‌تواند صدا بزند.
create or replace function public.payment_begin(p_commission uuid, p_driver uuid, p_gateway text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare c public.commissions; pid uuid;
begin
  select * into c from public.commissions where id = p_commission and driver_id = p_driver for update;
  if not found then raise exception 'not_found' using errcode = 'P0001'; end if;
  if c.status = 'paid' then raise exception 'already_paid' using errcode = 'P0001'; end if;
  if c.status <> 'due' or c.amount <= 0 then raise exception 'not_payable' using errcode = 'P0001'; end if;
  insert into public.commission_payments(commission_id, driver_id, gateway, amount)
  values (c.id, c.driver_id, p_gateway, c.amount) returning id into pid;
  insert into public.payment_events(payment_id, kind, ok, detail) values (pid, 'begin', true, jsonb_build_object('amount', c.amount));
  return jsonb_build_object('payment_id', pid, 'amount', c.amount);
end;
$$;

create or replace function public.payment_set_authority(p_payment uuid, p_authority text)
returns void language plpgsql security definer set search_path = public as $$
begin
  update public.commission_payments set authority = p_authority where id = p_payment and status = 'initiated' and authority is null;
  if not found then raise exception 'not_found' using errcode = 'P0001'; end if;
end;
$$;

create or replace function public.payment_abort(p_payment uuid, p_reason text)
returns void language plpgsql security definer set search_path = public as $$
begin
  update public.commission_payments set status = 'failed', failure_reason = left(coalesce(p_reason, ''), 200), verified_at = now()
   where id = p_payment and status = 'initiated' and authority is null;
  insert into public.payment_events(payment_id, kind, ok, detail) values (p_payment, 'abort', false, jsonb_build_object('reason', left(coalesce(p_reason, ''), 200)));
end;
$$;

create or replace function public.payment_mark_paid(p_authority text, p_ref_id text, p_card_pan text, p_detail jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare p public.commission_payments; c public.commissions;
begin
  select * into p from public.commission_payments where authority = p_authority for update;
  if not found then raise exception 'not_found' using errcode = 'P0001'; end if;
  if p.status = 'paid' then return jsonb_build_object('status', 'paid', 'already', true); end if;
  select * into c from public.commissions where id = p.commission_id for update;
  if c.status = 'paid' or exists (select 1 from public.commission_payments where commission_id = c.id and status = 'paid') then
    update public.commission_payments set status = 'duplicate', ref_id = p_ref_id, card_pan = p_card_pan, verified_at = now() where id = p.id;
    insert into public.payment_events(payment_id, kind, ok, detail) values (p.id, 'duplicate_payment', false, p_detail);
    return jsonb_build_object('status', 'duplicate', 'already', false);
  end if;
  update public.commission_payments set status = 'paid', ref_id = p_ref_id, card_pan = p_card_pan, verified_at = now(), failure_reason = null where id = p.id;
  update public.commissions set status = 'paid', paid_at = now() where id = c.id;
  insert into public.payment_events(payment_id, kind, ok, detail) values (p.id, 'verified_paid', true, p_detail);
  return jsonb_build_object('status', 'paid', 'already', false);
end;
$$;

create or replace function public.payment_mark_failed(p_authority text, p_status text, p_reason text, p_detail jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare p public.commission_payments;
begin
  if p_status not in ('failed','canceled') then raise exception 'bad_status' using errcode = 'P0001'; end if;
  select * into p from public.commission_payments where authority = p_authority for update;
  if not found then raise exception 'not_found' using errcode = 'P0001'; end if;
  if p.status <> 'initiated' then return jsonb_build_object('status', p.status, 'changed', false); end if;   -- پرداخت موفق هرگز تنزل نمی‌یابد
  update public.commission_payments set status = p_status, failure_reason = left(coalesce(p_reason, ''), 200), verified_at = now() where id = p.id;
  insert into public.payment_events(payment_id, kind, ok, detail) values (p.id, 'failed_' || p_status, false, p_detail);
  return jsonb_build_object('status', p_status, 'changed', true);
end;
$$;

revoke all on function public.payment_begin(uuid, uuid, text) from public, anon, authenticated;
revoke all on function public.payment_set_authority(uuid, text) from public, anon, authenticated;
revoke all on function public.payment_abort(uuid, text) from public, anon, authenticated;
revoke all on function public.payment_mark_paid(text, text, text, jsonb) from public, anon, authenticated;
revoke all on function public.payment_mark_failed(text, text, text, jsonb) from public, anon, authenticated;
do $$ begin
  if exists (select 1 from pg_roles where rolname = 'service_role') then
    grant execute on function public.payment_begin(uuid, uuid, text) to service_role;
    grant execute on function public.payment_set_authority(uuid, text) to service_role;
    grant execute on function public.payment_abort(uuid, text) to service_role;
    grant execute on function public.payment_mark_paid(text, text, text, jsonb) to service_role;
    grant execute on function public.payment_mark_failed(text, text, text, jsonb) to service_role;
    grant execute on function public.auto_complete_trips() to service_role;
  end if;
end $$;

-- ۱۴) پنل مدیریت درآمد (فقط مدیر؛ با توکن ورود خود مدیر، بدون هیچ کلید محرمانه‌ای)
create or replace function public.admin_revenue_summary(p_from date default null, p_to date default null)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare r jsonb;
begin
  if not public.is_admin() then raise exception 'not_admin' using errcode = 'P0001'; end if;
  select jsonb_build_object(
    'due_count',     count(*) filter (where status = 'due'),
    'due_amount',    coalesce(sum(amount) filter (where status = 'due'), 0),
    'overdue_count', count(*) filter (where status = 'due' and due_at < now()),
    'overdue_amount',coalesce(sum(amount) filter (where status = 'due' and due_at < now()), 0),
    'paid_count',    count(*) filter (where status = 'paid'),
    'paid_amount',   coalesce(sum(amount) filter (where status = 'paid'), 0),
    'waived_count',  count(*) filter (where status = 'waived'),
    'waived_amount', coalesce(sum(amount) filter (where status = 'waived'), 0),
    'gross_amount',  coalesce(sum(gross_amount), 0)
  ) into r
  from public.commissions
  where (p_from is null or trip_date >= p_from) and (p_to is null or trip_date <= p_to);
  return r || jsonb_build_object('duplicate_payments', (select count(*) from public.commission_payments where status = 'duplicate'));
end;
$$;

create or replace function public.admin_list_commissions(p_status text default null, p_limit int default 50, p_offset int default 0)
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not_admin' using errcode = 'P0001'; end if;
  return (select coalesce(jsonb_agg(x order by (x->>'completed_at') desc), '[]'::jsonb) from (
    select jsonb_build_object(
      'commission_id', c.id, 'trip_id', c.trip_id, 'origin', c.trip_origin, 'destination', c.trip_destination,
      'trip_date', c.trip_date, 'seats', c.seats_total, 'gross_amount', c.gross_amount, 'amount', c.amount,
      'status', c.status, 'source', c.source, 'completed_at', c.completed_at, 'due_at', c.due_at, 'paid_at', c.paid_at,
      'overdue', (c.status = 'due' and c.due_at < now()), 'waive_reason', c.waive_reason,
      'driver_name', p.name, 'driver_phone', p.phone, 'driver_verified', p.phone_verified
    ) as x
    from public.commissions c left join public.profiles p on p.id = c.driver_id
    where (p_status is null or c.status = p_status)
    order by c.completed_at desc limit least(greatest(p_limit, 1), 200) offset greatest(p_offset, 0)
  ) q);
end;
$$;

create or replace function public.admin_list_payments(p_limit int default 50, p_offset int default 0)
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not_admin' using errcode = 'P0001'; end if;
  return (select coalesce(jsonb_agg(x order by (x->>'created_at') desc), '[]'::jsonb) from (
    select jsonb_build_object('payment_id', p.id, 'commission_id', p.commission_id, 'amount', p.amount, 'gateway', p.gateway,
      'status', p.status, 'ref_id', p.ref_id, 'card_pan', p.card_pan, 'failure_reason', p.failure_reason,
      'created_at', p.created_at, 'verified_at', p.verified_at) as x
    from public.commission_payments p order by p.created_at desc limit least(greatest(p_limit, 1), 200) offset greatest(p_offset, 0)
  ) q);
end;
$$;

create or replace function public.admin_waive_commission(p_commission uuid, p_reason text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare c public.commissions;
begin
  if not public.is_admin() then raise exception 'not_admin' using errcode = 'P0001'; end if;
  if char_length(btrim(coalesce(p_reason, ''))) < 3 then raise exception 'reason_required' using errcode = 'P0001'; end if;
  select * into c from public.commissions where id = p_commission for update;
  if not found then raise exception 'not_found' using errcode = 'P0001'; end if;
  if c.status <> 'due' then raise exception 'already_decided' using errcode = 'P0001'; end if;
  update public.commissions set status = 'waived', waived_at = now(), waived_by = auth.uid(), waive_reason = left(btrim(p_reason), 200) where id = c.id;
  insert into public.payment_events(payment_id, kind, ok, detail)
    values (null, 'admin_waive', true, jsonb_build_object('commission_id', c.id, 'by', auth.uid(), 'reason', left(btrim(p_reason), 200)));
  return jsonb_build_object('status', 'waived');
end;
$$;

revoke all on function public.admin_revenue_summary(date, date) from public, anon;
revoke all on function public.admin_list_commissions(text, int, int) from public, anon;
revoke all on function public.admin_list_payments(int, int) from public, anon;
revoke all on function public.admin_waive_commission(uuid, text) from public, anon;
grant execute on function public.admin_revenue_summary(date, date) to authenticated;
grant execute on function public.admin_list_commissions(text, int, int) to authenticated;
grant execute on function public.admin_list_payments(int, int) to authenticated;
grant execute on function public.admin_waive_commission(uuid, text) to authenticated;

-- ---------------------------------------------------------------------
-- راه‌اندازی (بعد از تأیید طرح):
--  ۱) خودتان را مدیر کنید:  insert into public.app_admins(user_id) values ('<شناسه‌ی کاربری شما از Authentication ← Users>');
--  ۲) روشن کردن کمیسیون:     update public.commission_settings set enabled = true where id;
--  ۳) تکمیل خودکار شبانه (pg_cron):  select cron.schedule('hamsafar-autocomplete','15 * * * *',$$select public.auto_complete_trips()$$);
--
-- بخش اختیاری (پیش‌فرض اجرا نمی‌شود چون روی جدول trips تریگر می‌افزاید):
--  جلوگیری از ثبت سفر جدید برای رانده‌ای که کمیسیون سررسیدگذشته دارد.
-- ---------------------------------------------------------------------
